import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import random

# Create a directory for the sample data
os.makedirs('api/sample_data', exist_ok=True)

# Set random seed for reproducibility
np.random.seed(42)

# Generate sample transaction data
def generate_transaction_data(num_transactions=100, start_date='2024-01-01', end_date='2024-03-01'):
    # Convert string dates to datetime
    start = datetime.strptime(start_date, '%Y-%m-%d')
    end = datetime.strptime(end_date, '%Y-%m-%d')
    
    # Generate random dates between start and end
    days_range = (end - start).days
    random_days = sorted(np.random.randint(0, days_range, num_transactions))
    transaction_dates = [start + timedelta(days=int(days)) for days in random_days]
    
    # Generate random amounts (in TND - Tunisian Dinar)
    amounts = np.random.uniform(1000, 50000, num_transactions).round(2)
    
    # Generate random currencies for forex transactions
    currencies = ['EUR', 'USD', 'GBP', 'JPY', 'CHF', 'SAR', 'AED', 'CAD']
    transaction_currencies = np.random.choice(currencies, num_transactions)
    
    # Generate client IDs
    client_ids = np.random.randint(10000, 99999, num_transactions)
    
    # Generate transaction types
    transaction_types = np.random.choice(['Buy', 'Sell'], num_transactions)
    
    # Create the DataFrame
    df = pd.DataFrame({
        'transaction_date': transaction_dates,
        'amount': amounts,
        'currency': transaction_currencies,
        'client_id': client_ids,
        'transaction_type': transaction_types,
        'exchange_rate': np.random.uniform(0.2, 3.5, num_transactions).round(4)
    })
    
    # Sort by date
    df = df.sort_values('transaction_date')
    
    # Reset index
    df = df.reset_index(drop=True)
    
    return df

# Generate sample data
df_transactions = generate_transaction_data(num_transactions=150, 
                                           start_date='2024-01-01', 
                                           end_date='2024-03-15')

# Save to different formats for testing
df_transactions.to_csv('api/sample_data/sample_transactions.csv', index=False)

try:
    df_transactions.to_excel('api/sample_data/sample_transactions.xlsx', engine='openpyxl', index=False)
    print("Created sample Excel file (.xlsx)")
except Exception as e:
    print(f"Couldn't create Excel file: {str(e)}")

print(f"Created sample data with {len(df_transactions)} transactions")
print(f"Date range: {df_transactions['transaction_date'].min()} to {df_transactions['transaction_date'].max()}")
print(f"Sample data saved to api/sample_data/ directory")
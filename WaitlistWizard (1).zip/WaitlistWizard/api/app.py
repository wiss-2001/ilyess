from flask import Flask, request, jsonify
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from datetime import datetime, timedelta
import json
from werkzeug.utils import secure_filename
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import base64

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max upload
app.config['ALLOWED_EXTENSIONS'] = {'xlsb', 'xlsx', 'csv'}

# Create uploads folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Function to load and process XLSB data
def process_xlsb_data(file_path):
    try:
        if file_path.endswith('.xlsb'):
            df = pd.read_excel(file_path, engine='pyxlsb')
        elif file_path.endswith('.xlsx'):
            df = pd.read_excel(file_path, engine='openpyxl')
        elif file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        else:
            return None, "Unsupported file format"
        
        return df, None
    except Exception as e:
        return None, str(e)

# Function to transform data for time series analysis
def prepare_transaction_data(df):
    # Assume the DataFrame has columns: 'transaction_date', 'amount', 'currency', etc.
    # Convert date strings to datetime objects if needed
    if 'transaction_date' in df.columns:
        if not pd.api.types.is_datetime64_dtype(df['transaction_date']):
            df['transaction_date'] = pd.to_datetime(df['transaction_date'])
    
    # Sort by date
    df = df.sort_values('transaction_date')
    
    # Add features for time-based analysis
    df['dayofweek'] = df['transaction_date'].dt.dayofweek
    df['month'] = df['transaction_date'].dt.month
    df['year'] = df['transaction_date'].dt.year
    df['day'] = df['transaction_date'].dt.day
    
    # Calculate days between transactions
    df['days_since_prev'] = df['transaction_date'].diff().dt.days
    
    # Fill NaN values
    df = df.fillna(0)
    
    return df

# Function to train prediction model
def train_next_transaction_model(df):
    features = ['dayofweek', 'month', 'year', 'day', 'amount']
    target = 'days_since_prev'
    
    # Make sure all necessary columns exist
    for col in features + [target]:
        if col not in df.columns:
            # If amount column is missing, use a placeholder
            if col == 'amount' and 'amount' not in df.columns:
                df['amount'] = 1.0
            else:
                return None, f"Missing column: {col}"
    
    # Prepare the feature matrix and target vector
    X = df[features].values
    y = df[target].values
    
    # Split data for training and testing
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train a Random Forest Regressor
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Evaluate the model
    score = model.score(X_test, y_test)
    
    return model, score

# Function to predict next transaction date
def predict_next_transaction(model, last_transaction, amount=None):
    # Extract features from the last transaction
    day_of_week = last_transaction.dayofweek
    month = last_transaction.month
    year = last_transaction.year
    day = last_transaction.day
    
    # Use the amount if provided, otherwise default to 1.0
    if amount is None:
        amount = 1.0
    
    # Prepare the feature vector for prediction
    features = np.array([[day_of_week, month, year, day, amount]])
    
    # Predict days until next transaction
    days_until_next = model.predict(features)[0]
    
    # Calculate the predicted date
    next_date = last_transaction + timedelta(days=max(1, int(days_until_next)))
    
    return next_date, days_until_next

# Function to generate KPIs
def generate_kpis(df):
    kpis = {}
    
    # Basic transaction stats
    kpis['total_transactions'] = len(df)
    
    if 'amount' in df.columns:
        kpis['total_volume'] = df['amount'].sum()
        kpis['avg_transaction_value'] = df['amount'].mean()
        kpis['max_transaction_value'] = df['amount'].max()
    
    # Time-based metrics
    if 'transaction_date' in df.columns:
        kpis['first_transaction_date'] = df['transaction_date'].min().strftime('%Y-%m-%d')
        kpis['last_transaction_date'] = df['transaction_date'].max().strftime('%Y-%m-%d')
        kpis['date_range_days'] = (df['transaction_date'].max() - df['transaction_date'].min()).days
    
    # Frequency metrics
    if 'days_since_prev' in df.columns:
        kpis['avg_days_between_transactions'] = df['days_since_prev'].mean()
    
    # Currency distribution if available
    if 'currency' in df.columns:
        currency_counts = df['currency'].value_counts().to_dict()
        kpis['currency_distribution'] = currency_counts
    
    return kpis

# Function to generate visualizations
def generate_visualizations(df):
    visualizations = {}
    
    # Transaction volume over time
    if 'transaction_date' in df.columns:
        plt.figure(figsize=(10, 6))
        df_grouped = df.groupby(df['transaction_date'].dt.to_period('M')).size()
        df_grouped.plot(kind='bar')
        plt.title('Monthly Transaction Count')
        plt.tight_layout()
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()
        
        graphic = base64.b64encode(image_png).decode('utf-8')
        visualizations['monthly_transactions'] = graphic
    
    # Transaction value distribution
    if 'amount' in df.columns:
        plt.figure(figsize=(10, 6))
        sns.histplot(df['amount'], kde=True)
        plt.title('Transaction Value Distribution')
        plt.tight_layout()
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()
        
        graphic = base64.b64encode(image_png).decode('utf-8')
        visualizations['value_distribution'] = graphic
    
    # Day of week distribution
    if 'dayofweek' in df.columns:
        plt.figure(figsize=(10, 6))
        day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        sns.countplot(x=df['dayofweek'], order=range(7))
        plt.title('Transactions by Day of Week')
        plt.xticks(range(7), day_names)
        plt.tight_layout()
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()
        
        graphic = base64.b64encode(image_png).decode('utf-8')
        visualizations['day_of_week'] = graphic
    
    return visualizations

@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Process the uploaded file
        df, error = process_xlsb_data(file_path)
        
        if error:
            return jsonify({'error': f'Error processing file: {error}'}), 400
        
        # Prepare the data
        try:
            processed_df = prepare_transaction_data(df)
            
            # Train the model
            model, score = train_next_transaction_model(processed_df)
            
            if model is None:
                return jsonify({'error': f'Error training model: {score}'}), 400
            
            # Get the last transaction date
            last_transaction_date = processed_df['transaction_date'].max()
            
            # Predict the next transaction
            next_date, days_until_next = predict_next_transaction(model, last_transaction_date)
            
            # Generate KPIs
            kpis = generate_kpis(processed_df)
            
            # Generate visualizations
            visualizations = generate_visualizations(processed_df)
            
            result = {
                'filename': filename,
                'rows_processed': len(df),
                'model_accuracy': score,
                'last_transaction_date': last_transaction_date.strftime('%Y-%m-%d'),
                'predicted_next_transaction': next_date.strftime('%Y-%m-%d'),
                'days_until_next_transaction': int(days_until_next),
                'kpis': kpis,
                'visualizations': visualizations
            }
            
            return jsonify(result), 200
            
        except Exception as e:
            return jsonify({'error': f'Error analyzing data: {str(e)}'}), 400
    
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy'}), 200

@app.after_request
def after_request(response):
    header = response.headers
    header['Access-Control-Allow-Origin'] = '*'
    header['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    header['Access-Control-Allow-Methods'] = 'OPTIONS, HEAD, GET, POST, PUT, DELETE'
    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
from flask import Flask, request, jsonify
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from datetime import datetime, timedelta
import json
from werkzeug.utils import secure_filename
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import base64

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max upload
app.config['ALLOWED_EXTENSIONS'] = {'xlsb', 'xlsx', 'csv'}

# Create uploads folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Function to load and process XLSB data
def process_xlsb_data(file_path):
    try:
        if file_path.endswith('.xlsb'):
            df = pd.read_excel(file_path, engine='pyxlsb')
        elif file_path.endswith('.xlsx'):
            df = pd.read_excel(file_path, engine='openpyxl')
        elif file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        else:
            return None, "Unsupported file format"
        
        return df, None
    except Exception as e:
        return None, str(e)

# Enhanced data preparation with smart column detection
def prepare_transaction_data(df):
    # Common column name patterns
    date_columns = ['Date', 'date', 'DATE', 'Transaction Date', 'TransactionDate', 'Date_Transaction', 'transaction_date']
    amount_columns = ['Amount', 'amount', 'AMOUNT', 'Transaction Amount', 'TransactionAmount', 'Montant', 'montant']
    currency_columns = ['Currency', 'currency', 'CURRENCY', 'Devise', 'devise', 'CurrencyCode']
    client_columns = ['Client', 'client', 'CLIENT', 'ClientID', 'Client_ID', 'CustomerID', 'Customer_ID']
    
    # Map actual columns to standardized names
    column_mapping = {}
    
    # Find date column
    for col in date_columns:
        if col in df.columns:
            column_mapping[col] = 'transaction_date'
            break
    
    # Find amount column
    for col in amount_columns:
        if col in df.columns:
            column_mapping[col] = 'amount'
            break
    
    # Find currency column
    for col in currency_columns:
        if col in df.columns:
            column_mapping[col] = 'currency'
            break
    
    # Find client column
    for col in client_columns:
        if col in df.columns:
            column_mapping[col] = 'client_id'
            break
    
    # Rename columns for consistency
    if column_mapping:
        df = df.rename(columns=column_mapping)
    
    # Ensure required columns exist
    if 'transaction_date' not in df.columns:
        # Use first column as date if possible
        if df.shape[1] > 0:
            df = df.rename(columns={df.columns[0]: 'transaction_date'})
    
    if 'amount' not in df.columns:
        # Use second column as amount if possible
        if df.shape[1] > 1:
            df = df.rename(columns={df.columns[1]: 'amount'})
    
    # Convert date to datetime
    if 'transaction_date' in df.columns:
        # Try multiple date formats
        date_formats = ['%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%d-%m-%Y', '%Y/%m/%d']
        
        for fmt in date_formats:
            try:
                df['transaction_date'] = pd.to_datetime(df['transaction_date'], format=fmt, errors='raise')
                break
            except:
                continue
        
        # If all formats fail, use pandas' built-in parser
        if not pd.api.types.is_datetime64_dtype(df['transaction_date']):
            df['transaction_date'] = pd.to_datetime(df['transaction_date'], errors='coerce')
    
    # Convert amount to numeric
    if 'amount' in df.columns:
        # Remove any currency symbols or commas
        if df['amount'].dtype == object:
            df['amount'] = df['amount'].astype(str).str.replace(r'[^\d.-]', '', regex=True)
        df['amount'] = pd.to_numeric(df['amount'], errors='coerce')
    
    # Add category if missing
    if 'category' not in df.columns:
        if 'currency' in df.columns:
            # Use currency pairs as categories
            df['category'] = df['currency']
        else:
            df['category'] = 'Uncategorized'
    
    # Drop rows with missing critical data
    return df.dropna(subset=['transaction_date', 'amount'])

# Feature engineering for better prediction
def engineer_features(df):
    # Make a copy to avoid modifying the original
    df_features = df.copy()
    
    # Temporal features
    df_features['day_of_week'] = df_features['transaction_date'].dt.dayofweek
    df_features['day_of_month'] = df_features['transaction_date'].dt.day
    df_features['month'] = df_features['transaction_date'].dt.month
    df_features['year'] = df_features['transaction_date'].dt.year
    df_features['is_month_end'] = df_features['transaction_date'].dt.is_month_end.astype(int)
    df_features['is_month_start'] = df_features['transaction_date'].dt.is_month_start.astype(int)
    df_features['is_quarter_end'] = df_features['transaction_date'].dt.is_quarter_end.astype(int)
    
    # Transaction frequency features
    df_features = df_features.sort_values('transaction_date')
    df_features['days_since_previous'] = df_features['transaction_date'].diff().dt.days
    df_features['days_since_previous'] = df_features['days_since_previous'].fillna(0)
    
    # Rolling statistics on amount
    window_sizes = [2, 3, 5]
    for window in window_sizes:
        if len(df_features) >= window:
            df_features[f'amount_mean_{window}'] = df_features['amount'].rolling(window=window).mean()
            df_features[f'amount_std_{window}'] = df_features['amount'].rolling(window=window).std()
    
    # Fill NAs created by rolling windows
    df_features = df_features.fillna(method='bfill').fillna(method='ffill')
    
    return df_features

# Advanced prediction model with Random Forest
def train_prediction_models(df):
    if len(df) < 10:  # Need sufficient data
        return None, None, None, None
    
    # Engineer features
    df_features = engineer_features(df)
    
    # Prepare features for date prediction
    features_date = ['day_of_week', 'day_of_month', 'month', 'is_month_end', 'is_month_start']
    # Add lag features if available
    lag_features = [col for col in df_features.columns if 'days_since_previous' in col]
    features_date.extend(lag_features)
    
    # Prepare features for amount prediction
    features_amount = ['day_of_week', 'day_of_month', 'month', 'days_since_previous']
    # Add rolling amount features if available
    amount_features = [col for col in df_features.columns if 'amount_' in col]
    features_amount.extend(amount_features)
    
    # Ensure features exist in dataframe
    features_date = [f for f in features_date if f in df_features.columns]
    features_amount = [f for f in features_amount if f in df_features.columns]
    
    if not features_date or not features_amount:
        return None, None, None, None
    
    # Prepare data for training
    X_date = df_features[features_date].values
    y_date = df_features['days_since_previous'].values
    
    X_amount = df_features[features_amount].values
    y_amount = df_features['amount'].values
    
    # Train models using Random Forest
    date_model = RandomForestRegressor(n_estimators=100, random_state=42)
    date_model.fit(X_date, y_date)
    
    amount_model = RandomForestRegressor(n_estimators=100, random_state=42)
    amount_model.fit(X_amount, y_amount)
    
    return date_model, amount_model, features_date, features_amount

# Predict next transaction with confidence score
def predict_next_transaction(date_model, amount_model, df, date_features, amount_features):
    if date_model is None or amount_model is None or df.empty:
        return None
    
    # Get latest transaction
    df_sorted = df.sort_values('transaction_date')
    latest_tx = df_sorted.iloc[-1]
    latest_date = latest_tx['transaction_date']
    
    # Engineer features for prediction
    df_features = engineer_features(df)
    latest_features = df_features.iloc[-1]
    
    # Current date components
    today = datetime.now()
    next_days = []
    next_amounts = []
    
    # Make multiple predictions for ensemble averaging
    for i in range(3):  # Predict 3 times with different assumptions
        # Create prediction features
        date_pred_data = {}
        for feature in date_features:
            if feature in latest_features:
                date_pred_data[feature] = latest_features[feature]
                # Add some randomness for ensemble
                if i > 0 and feature in ['day_of_month', 'month']:
                    date_pred_data[feature] = (date_pred_data[feature] + i) % 12 if feature == 'month' else (date_pred_data[feature] + i) % 30
        
        # Convert to numpy array with correct order
        X_date_pred = np.array([[date_pred_data[f] for f in date_features]])
        
        # Predict days until next transaction
        days_prediction = max(1, int(date_model.predict(X_date_pred)[0]))
        next_days.append(days_prediction)
        
        # Calculate the predicted date
        predicted_date = latest_date + timedelta(days=days_prediction)
        
        # Create amount prediction features
        amount_pred_data = {}
        for feature in amount_features:
            if feature in latest_features:
                amount_pred_data[feature] = latest_features[feature]
                # Use predicted date features
                if feature == 'day_of_week':
                    amount_pred_data[feature] = predicted_date.weekday()
                elif feature == 'day_of_month':
                    amount_pred_data[feature] = predicted_date.day
                elif feature == 'month':
                    amount_pred_data[feature] = predicted_date.month
                elif feature == 'days_since_previous':
                    amount_pred_data[feature] = days_prediction
        
        # Convert to numpy array
        X_amount_pred = np.array([[amount_pred_data[f] for f in amount_features]])
        
        # Predict amount
        amount_prediction = max(0, float(amount_model.predict(X_amount_pred)[0]))
        next_amounts.append(amount_prediction)
    
    # Average ensemble predictions
    final_days = int(sum(next_days) / len(next_days))
    final_amount = float(sum(next_amounts) / len(next_amounts))
    
    # Calculate final date
    next_date = latest_date + timedelta(days=final_days)
    
    # Calculate confidence score (lower for longer predictions)
    base_confidence = 0.9
    time_penalty = min(0.3, (final_days / 365) * 0.5)  # Reduce confidence for long-term predictions
    consistency_bonus = 0.1 * (1 - (np.std(next_amounts) / (np.mean(next_amounts) + 1e-10)))  # More consistent predictions = higher confidence
    confidence = max(0.5, min(0.95, base_confidence - time_penalty + consistency_bonus))
    
    return {
        'nextTransactionDate': next_date.strftime('%Y-%m-%d'),
        'daysUntilNextTransaction': final_days,
        'predictedAmount': final_amount,
        'confidenceScore': float(confidence)
    }

# Client segmentation based on RFM (Recency, Frequency, Monetary)
def segment_clients(df):
    if 'client_id' not in df.columns or len(df) < 10:
        return None
    
    # Group by client
    client_stats = df.groupby('client_id').agg({
        'amount': ['count', 'mean', 'sum', 'std'],
        'transaction_date': ['min', 'max']
    })
    
    # Flatten the MultiIndex
    client_stats.columns = ['_'.join(col).strip() for col in client_stats.columns.values]
    
    # Calculate RFM metrics
    current_date = datetime.now()
    
    # Recency (days since last transaction)
    client_stats['recency_days'] = (current_date - client_stats['transaction_date_max']).dt.days
    
    # Frequency (count of transactions)
    client_stats['frequency'] = client_stats['amount_count']
    
    # Calculate client lifetime (days between first and last transaction)
    client_stats['lifetime_days'] = (client_stats['transaction_date_max'] - client_stats['transaction_date_min']).dt.days
    
    # Calculate average time between transactions
    client_stats['avg_days_between_tx'] = client_stats['lifetime_days'] / client_stats['amount_count']
    
    # Monetary value (total amount)
    client_stats['monetary'] = client_stats['amount_sum']
    
    # Select features for clustering
    features = ['recency_days', 'frequency', 'monetary']
    X = client_stats[features].copy()
    
    # Handle missing values
    X = X.fillna(X.mean())
    
    # Scale the data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Determine optimal number of clusters
    n_clusters = min(4, len(X) - 1)  # Use 4 clusters or fewer if not enough data
    
    # Apply KMeans clustering
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    client_stats['segment'] = kmeans.fit_predict(X_scaled)
    
    # Create meaningful segment names based on average value
    segment_values = client_stats.groupby('segment')['monetary'].mean().sort_values(ascending=False)
    
    segment_names = {
        segment_values.index[0]: 'Premium',
        segment_values.index[-1]: 'Low-Value'
    }
    
    # Add Middle segments depending on number of clusters
    if n_clusters >= 3:
        segment_names[segment_values.index[1]] = 'High-Value'
    if n_clusters >= 4:
        segment_names[segment_values.index[2]] = 'Mid-Value'
    
    # Map segment numbers to names
    client_stats['segment_name'] = client_stats['segment'].map(segment_names)
    
    # Prepare client segment data for return
    client_segments = client_stats.reset_index()[
        ['client_id', 'segment_name', 'recency_days', 'frequency', 'monetary', 'amount_mean']
    ]
    
    return client_segments.to_dict('records')

# Analyze currency and exchange pattern trends
def analyze_currency_trends(df):
    if 'currency' not in df.columns or 'amount' not in df.columns or len(df) < 5:
        return []
    
    currency_trends = []
    
    # Group by currency and date (monthly)
    if 'transaction_date' in df.columns:
        df['month'] = df['transaction_date'].dt.strftime('%Y-%m')
        currency_monthly = df.groupby(['currency', 'month']).agg({
            'amount': ['sum', 'count', 'mean'],
            'transaction_date': ['min', 'max']
        }).reset_index()
        
        # Flatten the MultiIndex
        currency_monthly.columns = ['_'.join(col).strip() if isinstance(col, tuple) else col for col in currency_monthly.columns]
        
        # Calculate growth for each currency
        for currency, group in currency_monthly.groupby('currency'):
            group = group.sort_values('month')
            
            # Calculate month-over-month growth
            group['volume_growth'] = group['amount_sum'].pct_change() * 100
            
            # Skip if not enough data
            if len(group) < 2:
                continue
                
            # Get latest data
            latest = group.iloc[-1]
            
            # Calculate average growth
            avg_growth = group['volume_growth'].mean()
            
            currency_trends.append({
                'currency': currency,
                'latestVolume': float(latest['amount_sum']),
                'transactionCount': int(latest['amount_count']),
                'averageAmount': float(latest['amount_mean']),
                'growth': float(avg_growth if not np.isnan(avg_growth) else 0),
                'trending': avg_growth > 0,
                'monthlyData': group[['month', 'amount_sum', 'amount_count', 'volume_growth']].fillna(0).to_dict('records')
            })
    
    return currency_trends

# Generate commercial opportunities based on analysis
def generate_opportunities(df, predictions, segments):
    opportunities = []
    
    if not predictions or 'client_id' not in df.columns:
        return opportunities
    
    # Find valuable clients
    valuable_clients = []
    if segments:
        valuable_clients = [
            s['client_id'] for s in segments 
            if s['segment_name'] in ['Premium', 'High-Value']
        ]
    
    # Sort by recent transactions if no segmentation
    if not valuable_clients and 'client_id' in df.columns:
        recent_df = df.sort_values('transaction_date', ascending=False)
        unique_clients = recent_df['client_id'].unique()
        valuable_clients = unique_clients[:min(10, len(unique_clients))]
    
    # For each valuable client
    for client_id in valuable_clients:
        # Get client transactions
        client_df = df[df['client_id'] == client_id].sort_values('transaction_date')
        
        if client_df.empty:
            continue
            
        # Get client's last transaction
        last_tx = client_df.iloc[-1]
        last_date = last_tx['transaction_date']
        
        # Calculate days since last transaction
        days_inactive = (datetime.now() - last_date).days
        
        # Get average transaction size
        avg_amount = client_df['amount'].mean()
        
        # Get client's preferred currencies
        client_currencies = []
        if 'currency' in client_df.columns:
            client_currencies = client_df['currency'].value_counts().to_dict()
        
        # Opportunity 1: Client inactive for too long
        if days_inactive > 60:  # Dormant for 2 months
            opportunities.append({
                'clientId': client_id,
                'type': 'reactivation',
                'title': f"Réactivation Client {client_id}",
                'description': f"Client inactif depuis {days_inactive} jours",
                'expectedAmount': float(avg_amount),
                'preferredCurrencies': client_currencies,
                'priority': 'high' if days_inactive > 90 else 'medium',
                'probabilite': 0.5
            })
        
        # Opportunity 2: Upcoming transaction based on prediction
        elif days_inactive > 15:  # Not super recent
            next_date = datetime.strptime(predictions['nextTransactionDate'], '%Y-%m-%d')
            days_to_next = (next_date - datetime.now()).days
            
            if days_to_next < 14 and days_to_next > -7:  # Within 2 weeks of predicted date
                opportunities.append({
                    'clientId': client_id,
                    'type': 'upcoming',
                    'title': f"Transaction Prévue - Client {client_id}",
                    'description': f"Transaction prévue dans {max(0, days_to_next)} jours",
                    'expectedAmount': float(predictions['predictedAmount']),
                    'preferredCurrencies': client_currencies,
                    'priority': 'medium',
                    'probabilite': float(predictions['confidenceScore'])
                })
        
        # Opportunity 3: Upsell based on transaction history
        if len(client_df) >= 3:
            growth_trend = client_df['amount'].pct_change().mean() * 100
            
            if growth_trend > 0:  # Growing transaction sizes
                opportunities.append({
                    'clientId': client_id,
                    'type': 'upsell',
                    'title': f"Opportunité d'Upsell - Client {client_id}",
                    'description': f"Tendance croissante de {growth_trend:.1f}% par transaction",
                    'expectedAmount': float(avg_amount * 1.2),  # 20% higher than average
                    'preferredCurrencies': client_currencies,
                    'priority': 'medium',
                    'probabilite': 0.7
                })
    
    return opportunities

# Generate KPIs and metrics
def generate_kpis(df):
    kpis = {
        'totalTransactions': len(df),
        'totalAmount': float(df['amount'].sum()) if 'amount' in df.columns else 0,
        'averageTransactionAmount': float(df['amount'].mean()) if 'amount' in df.columns else 0,
        'minTransactionAmount': float(df['amount'].min()) if 'amount' in df.columns else 0,
        'maxTransactionAmount': float(df['amount'].max()) if 'amount' in df.columns else 0,
        'medianTransactionAmount': float(df['amount'].median()) if 'amount' in df.columns else 0,
        'stdDevTransactionAmount': float(df['amount'].std()) if 'amount' in df.columns else 0,
    }
    
    # Date-based metrics
    if 'transaction_date' in df.columns and not df['transaction_date'].empty:
        kpis['firstTransactionDate'] = df['transaction_date'].min().strftime('%Y-%m-%d')
        kpis['lastTransactionDate'] = df['transaction_date'].max().strftime('%Y-%m-%d')
        kpis['dateRangeDays'] = int((df['transaction_date'].max() - df['transaction_date'].min()).days)
        
        # Time between transactions
        df_sorted = df.sort_values('transaction_date')
        day_diffs = df_sorted['transaction_date'].diff().dt.days.dropna()
        kpis['avgDaysBetweenTransactions'] = float(day_diffs.mean()) if not day_diffs.empty else 0
    
    # Client metrics
    if 'client_id' in df.columns:
        kpis['uniqueClients'] = int(df['client_id'].nunique())
        
        # Transactions per client
        tx_per_client = df.groupby('client_id').size()
        kpis['avgTransactionsPerClient'] = float(tx_per_client.mean())
        kpis['maxTransactionsPerClient'] = int(tx_per_client.max())
    
    # Currency metrics
    if 'currency' in df.columns:
        kpis['uniqueCurrencies'] = int(df['currency'].nunique())
        currency_counts = df['currency'].value_counts()
        kpis['topCurrency'] = currency_counts.index[0] if not currency_counts.empty else 'Unknown'
    
    # Monthly transaction counts
    if 'transaction_date' in df.columns:
        monthly_counts = df.groupby(df['transaction_date'].dt.strftime('%Y-%m')).size()
        monthly_counts = monthly_counts.reset_index()
        monthly_counts.columns = ['month', 'count']
        kpis['transactionsByMonth'] = monthly_counts.to_dict('records')
    
    # Category distribution
    if 'category' in df.columns and 'amount' in df.columns:
        category_amounts = df.groupby('category')['amount'].sum().reset_index()
        kpis['transactionAmountByCategory'] = category_amounts.to_dict('records')
    
    # Transaction frequency data
    if 'transaction_date' in df.columns:
        df_sorted = df.sort_values('transaction_date')
        df_sorted['days_since_previous'] = df_sorted['transaction_date'].diff().dt.days
        frequency_data = df_sorted[['transaction_date', 'days_since_previous']].dropna()
        frequency_data['date'] = frequency_data['transaction_date'].dt.strftime('%Y-%m-%d')
        frequency_data = frequency_data.rename(columns={'days_since_previous': 'interval'})
        kpis['transactionFrequency'] = frequency_data[['date', 'interval']].to_dict('records')
    
    return kpis

# Generate visualizations
def generate_visualizations(df):
    visualizations = {}
    
    if 'transaction_date' not in df.columns or 'amount' not in df.columns or df.empty:
        return visualizations
    
    # Set Seaborn style
    sns.set_style("whitegrid")
    
    # 1. Transaction amount over time
    plt.figure(figsize=(12, 6))
    sns.lineplot(x='transaction_date', y='amount', data=df, marker='o')
    plt.title('Montant des Transactions au Fil du Temps', fontsize=16)
    plt.xlabel('Date', fontsize=12)
    plt.ylabel('Montant', fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Save to base64
    buffer = BytesIO()
    plt.savefig(buffer, format='png', dpi=100)
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()
    
    visualizations['amountOverTime'] = base64.b64encode(image_png).decode('utf-8')
    
    # 2. Distribution of transaction amounts
    plt.figure(figsize=(12, 6))
    sns.histplot(df['amount'], kde=True, bins=20, color='blue')
    plt.title('Distribution des Montants de Transaction', fontsize=16)
    plt.xlabel('Montant', fontsize=12)
    plt.ylabel('Fréquence', fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    buffer = BytesIO()
    plt.savefig(buffer, format='png', dpi=100)
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()
    
    visualizations['amountDistribution'] = base64.b64encode(image_png).decode('utf-8')
    
    # 3. Category distribution (if available)
    if 'category' in df.columns:
        plt.figure(figsize=(12, 6))
        category_counts = df['category'].value_counts()
        
        # Limit to top 10 categories if there are too many
        if len(category_counts) > 10:
            category_counts = category_counts.head(10)
            
        sns.barplot(x=category_counts.index, y=category_counts.values)
        plt.title('Transactions par Catégorie', fontsize=16)
        plt.xlabel('Catégorie', fontsize=12)
        plt.ylabel('Nombre', fontsize=12)
        plt.xticks(rotation=45)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=100)
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()
        
        visualizations['categoryDistribution'] = base64.b64encode(image_png).decode('utf-8')
    
    # 4. Transaction frequency (days between transactions)
    df_sorted = df.sort_values('transaction_date')
    df_sorted['days_since_previous'] = df_sorted['transaction_date'].diff().dt.days
    
    if not df_sorted['days_since_previous'].dropna().empty:
        plt.figure(figsize=(12, 6))
        sns.histplot(df_sorted['days_since_previous'].dropna(), kde=True, bins=10, color='purple')
        plt.title('Intervalle entre Transactions (Jours)', fontsize=16)
        plt.xlabel('Jours', fontsize=12)
        plt.ylabel('Fréquence', fontsize=12)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=100)
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()
        
        visualizations['transactionInterval'] = base64.b64encode(image_png).decode('utf-8')
    
    # 5. Monthly trends
    if len(df) >= 10:  # Need enough data for monthly trend
        monthly_data = df.set_index('transaction_date')
        monthly_mean = monthly_data.resample('M')['amount'].mean().reset_index()
        monthly_count = monthly_data.resample('M').size().reset_index()
        monthly_count.columns = ['transaction_date', 'count']
        
        # Merge data
        monthly_stats = pd.merge(monthly_mean, monthly_count, on='transaction_date')
        
        plt.figure(figsize=(12, 6))
        fig, ax1 = plt.subplots(figsize=(12, 6))
        
        color = 'tab:blue'
        ax1.set_xlabel('Date', fontsize=12)
        ax1.set_ylabel('Montant Moyen', color=color, fontsize=12)
        ax1.plot(monthly_stats['transaction_date'], monthly_stats['amount'], color=color, marker='o')
        ax1.tick_params(axis='y', labelcolor=color)
        
        ax2 = ax1.twinx()
        color = 'tab:red'
        ax2.set_ylabel('Nombre de Transactions', color=color, fontsize=12)
        ax2.plot(monthly_stats['transaction_date'], monthly_stats['count'], color=color, marker='s')
        ax2.tick_params(axis='y', labelcolor=color)
        
        plt.title('Tendances Mensuelles', fontsize=16)
        plt.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        fig.tight_layout()
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=100)
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close(fig)
        
        visualizations['monthlyTrends'] = base64.b64encode(image_png).decode('utf-8')
    
    return visualizations

# Enhanced file upload and analysis endpoint
@app.route('/api/transactions/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Save the file
        file.save(file_path)
        
        # Process the file
        df, error = process_xlsb_data(file_path)
        
        if error or df is None or df.empty:
            return jsonify({
                'success': False, 
                'message': f'Failed to process file: {error or "File is empty"}'
            })
        
        # Prepare and clean the data
        df = prepare_transaction_data(df)
        
        if df.empty:
            return jsonify({
                'success': False, 
                'message': 'No valid transaction data found in file'
            })
        
        # Train prediction models
        date_model, amount_model, date_features, amount_features = train_prediction_models(df)
        
        # Generate predictions
        prediction = predict_next_transaction(date_model, amount_model, df, date_features, amount_features)
        
        # Generate client segmentation
        client_segments = segment_clients(df)
        
        # Generate currency trend analysis
        currency_trends = analyze_currency_trends(df)
        
        # Generate commercial opportunities
        opportunities = generate_opportunities(df, prediction, client_segments)
        
        # Generate KPIs
        kpis = generate_kpis(df)
        
        # Generate visualizations
        visualizations = generate_visualizations(df)
        
        # Prepare response
        response = {
            'success': True,
            'analysis': {
                'filename': filename,
                'totalTransactions': len(df),
                'analysisDate': datetime.now().isoformat(),
                'lastTransactionDate': df['transaction_date'].max().strftime('%Y-%m-%d') if 'transaction_date' in df.columns and not df.empty else None,
                'predictions': prediction,
                'kpis': kpis,
                'visualizations': visualizations,
                'clientSegments': client_segments,
                'currencyTrends': currency_trends,
                'commercialOpportunities': opportunities
            }
        }
        
        return jsonify(response)
        
    return jsonify({'success': False, 'message': 'Invalid file type'})

# Endpoint to get all analyses (placeholder for database integration)
@app.route('/api/transactions/analyses', methods=['GET'])
def get_all_analyses():
    return jsonify({
        'success': True,
        'analyses': [],
        'total': 0
    })

# Endpoint to get recent analyses (placeholder)
@app.route('/api/transactions/analyses/recent', methods=['GET'])
def get_recent_analyses():
    limit = request.args.get('limit', default=5, type=int)
    return jsonify({
        'success': True,
        'analyses': [],
        'total': 0
    })

# Endpoint to get specific analysis by filename (placeholder)
@app.route('/api/transactions/analyses/<filename>', methods=['GET'])
def get_analysis_by_filename(filename):
    return jsonify({
        'success': False,
        'message': 'Analysis not found'
    })

# Health check endpoint
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy'})

# Add CORS headers
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
    return response

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
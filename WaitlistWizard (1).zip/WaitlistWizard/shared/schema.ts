import { pgTable, text, serial, integer, boolean, timestamp, json, real, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Waitlist schema (existing)
export const waitlistEntries = pgTable("waitlist_entries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  company: text("company"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertWaitlistEntrySchema = createInsertSchema(waitlistEntries).pick({
  name: true,
  email: true,
  company: true,
});

export const waitlistEntryValidationSchema = insertWaitlistEntrySchema.extend({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  company: z.string().optional(),
});

export type InsertWaitlistEntry = z.infer<typeof insertWaitlistEntrySchema>;
export type WaitlistEntry = typeof waitlistEntries.$inferSelect;

// Transaction Analysis Types
export const transactionFileSchema = z.object({
  filename: z.string(),
  fileType: z.enum(['csv', 'xlsx', 'xlsb']),
  uploadDate: z.date().optional().default(() => new Date()),
});

// Structure for monthly transaction counts
export const monthlyTransactionSchema = z.object({
  month: z.string(),
  count: z.number()
});

// Structure for category distribution
export const categoryAmountSchema = z.object({
  category: z.string(),
  amount: z.number()
});

// Structure for transaction frequency
export const transactionFrequencySchema = z.object({
  date: z.string(),
  interval: z.number()
});

export const transactionKPISchema = z.object({
  total_transactions: z.number(),
  totalTransactionAmount: z.number().optional(),
  totalAmount: z.number().optional(),
  averageTransactionAmount: z.number().optional(),
  minTransactionAmount: z.number().optional(),
  maxTransactionAmount: z.number().optional(),
  medianTransactionAmount: z.number().optional(),
  stdDevTransactionAmount: z.number().optional(),
  first_transaction_date: z.string().optional(),
  firstTransactionDate: z.string().optional(),
  last_transaction_date: z.string().optional(),
  lastTransactionDate: z.string().optional(),
  date_range_days: z.number().optional(),
  dateRangeDays: z.number().optional(),
  avg_days_between_transactions: z.number().optional(),
  avgDaysBetweenTransactions: z.number().optional(),
  uniqueClients: z.number().optional(),
  avgTransactionsPerClient: z.number().optional(),
  maxTransactionsPerClient: z.number().optional(),
  uniqueCurrencies: z.number().optional(),
  topCurrency: z.string().optional(),
  currency_distribution: z.record(z.string(), z.number()).optional(),
  // For visual displays
  transactionsByMonth: z.array(monthlyTransactionSchema).optional(),
  transactionAmountByCategory: z.array(categoryAmountSchema).optional(),
  transactionFrequency: z.array(transactionFrequencySchema).optional()
});

// Define client segment schema for enhanced dashboard
export const clientSegmentSchema = z.object({
  clientId: z.union([z.string(), z.number()]),
  segmentName: z.string(),
  recencyDays: z.number(),
  frequency: z.number(),
  monetary: z.number(),
  amountMean: z.number()
});

// Define commercial opportunity schema for enhanced dashboard
export const commercialOpportunitySchema = z.object({
  clientId: z.union([z.string(), z.number()]),
  type: z.string(),
  title: z.string(),
  description: z.string(),
  expectedAmount: z.number(),
  preferredCurrencies: z.record(z.string(), z.number()).optional(),
  priority: z.string(),
  probabilite: z.number()
});

// Define currency trend schema for enhanced dashboard
export const currencyTrendSchema = z.object({
  currency: z.string(),
  latestVolume: z.number(),
  transactionCount: z.number(),
  averageAmount: z.number(),
  growth: z.number(),
  trending: z.boolean(),
  monthlyData: z.array(z.object({
    month: z.string(),
    amount_sum: z.number(),
    amount_count: z.number(),
    volume_growth: z.number()
  })).optional()
});

export const transactionPredictionSchema = z.object({
  filename: z.string(),
  totalTransactions: z.number(),
  modelAccuracy: z.number().optional(),
  analysisDate: z.date().default(() => new Date()),
  lastTransactionDate: z.string().optional(),
  predictions: z.object({
    nextTransactionDate: z.string(),
    daysUntilNextTransaction: z.number().optional(),
    predictedAmount: z.number().optional(),
    confidenceScore: z.number().optional(),
  }).optional(),
  kpis: transactionKPISchema,
  visualizations: z.record(z.string(), z.string()).optional(), // Base64 encoded images
  clientSegments: z.array(clientSegmentSchema).optional(),
  commercialOpportunities: z.array(commercialOpportunitySchema).optional(),
  currencyTrends: z.array(currencyTrendSchema).optional()
});

export type TransactionFile = z.infer<typeof transactionFileSchema>;
export type TransactionKPI = z.infer<typeof transactionKPISchema>;
export type TransactionPrediction = z.infer<typeof transactionPredictionSchema>;

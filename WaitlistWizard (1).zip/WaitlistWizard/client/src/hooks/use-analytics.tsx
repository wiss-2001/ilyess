import { useEffect } from "react";
import { trackPageView } from "@/lib/analytics";

// Hook to track page views
export const useAnalytics = () => {
  useEffect(() => {
    // Track page view when component mounts
    trackPageView();
  }, []);
};

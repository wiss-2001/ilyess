import { useCallback, useEffect } from "react";

export const useReveal = () => {
  const revealElements = useCallback(() => {
    const reveals = document.querySelectorAll(".reveal");
    
    for (let i = 0; i < reveals.length; i++) {
      const windowHeight = window.innerHeight;
      const elementTop = reveals[i].getBoundingClientRect().top;
      const elementVisible = 150;
      
      if (elementTop < windowHeight - elementVisible) {
        reveals[i].classList.add("active");
      } else {
        // Optional: remove the active class if you want elements to hide again when scrolled away
        // reveals[i].classList.remove("active");
      }
    }
  }, []);

  const setupReveal = useCallback(() => {
    // Add CSS to the document for the reveal animation
    const style = document.createElement("style");
    style.innerHTML = `
      .reveal {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
      }
      
      .reveal.active {
        opacity: 1;
        transform: translateY(0);
      }
      
      .feature-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px -5px rgba(59, 130, 246, 0.1), 0 10px 10px -5px rgba(59, 130, 246, 0.04);
      }
    `;
    document.head.appendChild(style);

    window.addEventListener("scroll", revealElements);
    revealElements(); // Call once on initial load
    
    return () => {
      window.removeEventListener("scroll", revealElements);
      document.head.removeChild(style);
    };
  }, [revealElements]);

  return { setupReveal };
};

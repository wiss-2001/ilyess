import React, { useState, useCallback } from 'react';
import { Link } from 'wouter';
import { BarChart3, Bell, Users, Target, Upload, Download, TrendingUp, FileUp, PieChart, ArrowUpDown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart as RechartsPieChart, 
  Pie, 
  Cell 
} from "recharts";
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { uploadTransactionFile } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const BiatDashboard = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [analysisData, setAnalysisData] = useState<any | null>(null);

  // Simulate upload progress
  React.useEffect(() => {
    if (isUploading && uploadProgress < 90) {
      const timer = setTimeout(() => {
        setUploadProgress(prev => prev + 10);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isUploading, uploadProgress]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(10);

    try {
      const response = await uploadTransactionFile(selectedFile);
      setUploadProgress(100);
      setAnalysisData(response.analysis);
      toast({
        title: "Analyse réussie",
        description: "Vos données ont été analysées avec succès.",
      });
    } catch (error) {
      toast({
        title: "Erreur d'analyse",
        description: error instanceof Error ? error.message : "Une erreur est survenue lors de l'analyse",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR');
  };

  // Sample data for demo
  const transactions = [
    { date: '2023-10-01', montant: 1200 },
    { date: '2023-10-02', montant: 1500 },
    { date: '2023-10-03', montant: 1800 },
    { date: '2023-10-04', montant: 2200 },
    { date: '2023-10-05', montant: 2000 },
    { date: '2023-10-06', montant: 2500 },
    { date: '2023-10-07', montant: 2800 },
  ];

  const predictions = [
    { clientId: 1, clientName: 'Société A', datePrevue: '2023-10-15', montantPrevu: 3500, deviseSourcePrevue: 'EUR', deviseTargetPrevue: 'USD', probabilite: 0.82, opportuniteCommerciale: 'Opportunité de couverture' },
    { clientId: 2, clientName: 'Société B', datePrevue: '2023-10-17', montantPrevu: 2700, deviseSourcePrevue: 'USD', deviseTargetPrevue: 'EUR', probabilite: 0.75, opportuniteCommerciale: 'Cross-selling devise' },
    { clientId: 3, clientName: 'Société C', datePrevue: '2023-10-20', montantPrevu: 5200, deviseSourcePrevue: 'EUR', deviseTargetPrevue: 'GBP', probabilite: 0.91, opportuniteCommerciale: 'Augmentation volume' },
  ];

  return (
    <div className="bg-gray-50 min-h-screen">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <img 
              src="https://www.biat.com.tn/sites/default/files/logobiat_0_0.png" 
              alt="BIAT Logo" 
              className="h-14 w-auto"
            />
            <h2 className="text-3xl font-semibold text-gray-950">BIAT PROACTIFX Prediction</h2>
          </div>

          <nav className="flex space-x-4">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-2 rounded-md text-base font-medium ${activeTab === 'dashboard' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <BarChart3 className="h-5 w-5 inline-block mr-1" />
              Tableau de Bord
            </button>
            <button
              onClick={() => setActiveTab('clients')}
              className={`px-3 py-2 rounded-md text-base font-medium ${activeTab === 'clients' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Users className="h-5 w-5 inline-block mr-1" />
              Clients
            </button>
            <button
              onClick={() => setActiveTab('opportunites')}
              className={`px-3 py-2 rounded-md text-base font-medium ${activeTab === 'opportunites' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Target className="h-5 w-5 inline-block mr-1" />
              Opportunités
            </button>
            <button
              onClick={() => setActiveTab('alerts')}
              className={`px-3 py-2 rounded-md text-base font-medium ${activeTab === 'alerts' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Bell className="h-5 w-5 inline-block mr-1" />
              Alertes
            </button>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold">Tableau de Bord Prédictif</h1>
              
              <div className="flex space-x-4">
                <label className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 cursor-pointer">
                  <Upload className="h-5 w-5 mr-2" />
                  Importer XLSB
                  <input
                    type="file"
                    accept=".xlsb,.xls,.xlsx,.csv"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </label>
                
                <Button 
                  onClick={handleUpload} 
                  disabled={!selectedFile || isUploading}
                  className="bg-green-500 hover:bg-green-600"
                >
                  {isUploading ? (
                    <>
                      <span className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"></span>
                      Analyse en cours...
                    </>
                  ) : (
                    <>
                      <FileUp className="mr-2 h-5 w-5" />
                      Analyser
                    </>
                  )}
                </Button>
                
                {analysisData && (
                  <Button variant="outline" onClick={() => console.log("Export")}>
                    <Download className="mr-2 h-5 w-5" />
                    Exporter
                  </Button>
                )}
              </div>
            </div>

            {isUploading && (
              <div className="bg-white rounded-lg shadow p-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Analyse en cours...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              </div>
            )}

            {selectedFile && !isUploading && (
              <div className="bg-white rounded-lg shadow p-4">
                <div className="flex items-center text-sm text-gray-600">
                  <FileUp className="h-4 w-4 mr-2 text-blue-500" />
                  <span>Fichier sélectionné: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)</span>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-medium text-gray-900">Volume Total</h3>
                    <TrendingUp className="h-5 w-5 text-green-500" />
                  </div>
                  <p className="mt-2 text-3xl font-semibold">1.25M EUR</p>
                  <p className="text-sm text-gray-500">+12% vs mois précédent</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-medium text-gray-900">Clients Actifs</h3>
                    <Users className="h-5 w-5 text-blue-500" />
                  </div>
                  <p className="mt-2 text-3xl font-semibold">24</p>
                  <p className="text-sm text-gray-500">+3 nouveaux ce mois</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-medium text-gray-900">Opportunités</h3>
                    <Target className="h-5 w-5 text-purple-500" />
                  </div>
                  <p className="mt-2 text-3xl font-semibold">8</p>
                  <p className="text-sm text-gray-500">350k EUR potentiel</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Prévisions des Transactions</CardTitle>
                <CardDescription>Évolution des montants de transaction sur la période</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={transactions}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={(value) => new Date(value).toLocaleDateString('fr-FR', {day: '2-digit', month: '2-digit'})}
                      />
                      <YAxis />
                      <RechartsTooltip 
                        formatter={(value: any) => [`${value} EUR`, 'Montant']}
                        labelFormatter={(label) => new Date(label).toLocaleDateString('fr-FR')}
                      />
                      <Bar dataKey="montant" name="Montant" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Prochaines Transactions Prévues</CardTitle>
                <CardDescription>Basées sur l'analyse prédictive des données historiques</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead>
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Client
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date Prévue
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Montant
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Devise
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Probabilité
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Opportunité
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {predictions.map((prediction, index) => (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {prediction.clientName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {format(new Date(prediction.datePrevue), 'dd/MM/yyyy', { locale: fr })}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {prediction.montantPrevu.toLocaleString()} {prediction.deviseSourcePrevue}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {prediction.deviseSourcePrevue} → {prediction.deviseTargetPrevue}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <div className="flex items-center">
                              <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                                <div 
                                  className={`h-2.5 rounded-full ${prediction.probabilite > 0.8 ? 'bg-green-500' : prediction.probabilite > 0.6 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                  style={{ width: `${prediction.probabilite * 100}%` }}
                                ></div>
                              </div>
                              <span>{(prediction.probabilite * 100).toFixed(0)}%</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500">
                            {prediction.opportuniteCommerciale}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {analysisData && analysisData.visualizations && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {analysisData.visualizations.amountOverTime && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Montants des Transactions</CardTitle>
                      <CardDescription>Évolution temporelle</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="relative aspect-video w-full">
                        <img 
                          src={`data:image/png;base64,${analysisData.visualizations.amountOverTime}`} 
                          alt="Amount Over Time" 
                          className="w-full h-full object-contain"
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {analysisData.visualizations.amountDistribution && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Distribution des Montants</CardTitle>
                      <CardDescription>Histogramme des valeurs</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="relative aspect-video w-full">
                        <img 
                          src={`data:image/png;base64,${analysisData.visualizations.amountDistribution}`} 
                          alt="Amount Distribution" 
                          className="w-full h-full object-contain"
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
            
            {analysisData && analysisData.clientSegments && (
              <Card>
                <CardHeader>
                  <CardTitle>Segmentation Clients</CardTitle>
                  <CardDescription>Analyse par groupe de valeur</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {(['Premium', 'High-Value', 'Mid-Value'].map((segment, index) => {
                      const segmentClients = analysisData.clientSegments.filter(
                        (s: any) => s.segmentName === segment
                      );
                      const count = segmentClients.length;
                      
                      return (
                        <div key={index} className="bg-white p-4 rounded-lg border">
                          <h4 className="font-semibold text-gray-900">{segment}</h4>
                          <p className="text-3xl font-bold my-2">{count}</p>
                          <p className="text-sm text-gray-500">
                            {segment === 'Premium' 
                              ? 'Clients à haute valeur' 
                              : segment === 'High-Value' 
                                ? 'Clients à fort potentiel' 
                                : 'Clients standard'}
                          </p>
                        </div>
                      );
                    }))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === 'clients' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">Segmentation Clients</h1>
            
            {analysisData && analysisData.clientSegments ? (
              <Card>
                <CardHeader>
                  <CardTitle>Répartition des clients par segment</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Client</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Segment</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Récence (jours)</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fréquence</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valeur</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {analysisData.clientSegments.slice(0, 10).map((client: any, index: number) => (
                          <tr key={index}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{client.clientId}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                client.segmentName === 'Premium' ? 'bg-blue-100 text-blue-800' :
                                client.segmentName === 'High-Value' ? 'bg-green-100 text-green-800' :
                                'bg-gray-100 text-gray-800'
                              }`}>
                                {client.segmentName}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.recencyDays}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.frequency}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {formatAmount(client.monetary)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-10 text-center">
                  <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune donnée client disponible</h3>
                  <p className="text-gray-500">
                    Veuillez importer et analyser un fichier de transactions pour accéder aux données client.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === 'opportunites' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">Opportunités Commerciales</h1>
            
            {analysisData && analysisData.commercialOpportunities ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {analysisData.commercialOpportunities.map((opportunity: any, index: number) => (
                  <Card key={index} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-lg">{opportunity.title}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          opportunity.priority === 'high' ? 'bg-red-100 text-red-800' :
                          opportunity.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {opportunity.priority === 'high' ? 'Haute' : 
                           opportunity.priority === 'medium' ? 'Moyenne' : 'Basse'}
                        </span>
                      </div>
                      
                      <p className="text-gray-600 mb-4">{opportunity.description}</p>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Client ID:</span>
                          <span className="font-medium">{opportunity.clientId}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Montant prévu:</span>
                          <span className="font-medium">{formatAmount(opportunity.expectedAmount)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Probabilité:</span>
                          <span className="font-medium">{Math.round(opportunity.probabilite * 100)}%</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-end mt-4 space-x-2">
                        <Button size="sm" variant="outline">
                          <Bell className="h-4 w-4 mr-1" />
                          Rappel
                        </Button>
                        <Button size="sm">
                          Contacter
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-10 text-center">
                  <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune opportunité disponible</h3>
                  <p className="text-gray-500">
                    Veuillez importer et analyser un fichier de transactions pour identifier des opportunités.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === 'alerts' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">Alertes et Notifications</h1>
            
            <Card>
              <CardContent className="p-0">
                <div className="divide-y divide-gray-200">
                  <div className="p-4 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 pt-0.5">
                        <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                          <Bell className="h-5 w-5 text-yellow-600" />
                        </div>
                      </div>
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          Transaction inhabituelle détectée
                        </p>
                        <p className="mt-1 text-sm text-gray-500">
                          Client ID 1042 - Montant 15,000 EUR - 25% supérieur à la moyenne
                        </p>
                        <div className="mt-2 text-xs text-gray-400">
                          Il y a 3 heures
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 pt-0.5">
                        <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                          <Users className="h-5 w-5 text-green-600" />
                        </div>
                      </div>
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          Nouveau client à fort potentiel
                        </p>
                        <p className="mt-1 text-sm text-gray-500">
                          Client ID 2103 - 3 transactions en 2 jours - Total 8,500 EUR
                        </p>
                        <div className="mt-2 text-xs text-gray-400">
                          Hier
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 pt-0.5">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <TrendingUp className="h-5 w-5 text-blue-600" />
                        </div>
                      </div>
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          Opportunité de transaction imminente
                        </p>
                        <p className="mt-1 text-sm text-gray-500">
                          Client ID 965 - Prévision dans 2 jours - ~5,000 EUR
                        </p>
                        <div className="mt-2 text-xs text-gray-400">
                          Il y a 2 jours
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
};

export default BiatDashboard;
import React from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { TrendingUp, BarChart3, PieChart } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden" id="hero">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center">
          <motion.div 
            className="w-full lg:w-1/2 text-center lg:text-left mb-12 lg:mb-0"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">BIAT PROACTIFX</span> Prediction
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto lg:mx-0">
              Plateforme avancée d'analyse et prédiction pour les opérations de change. Transformez vos données en insights stratégiques pour une gestion proactive.
            </p>
            <div className="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
              <Button
                size="lg"
                className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-1"
                asChild
              >
                <Link href="/biat-dashboard">
                  <TrendingUp className="mr-2 h-5 w-5" />
                  BIAT Dashboard
                </Link>
              </Button>
              <Button
                size="lg"
                className="px-8 py-3 bg-primary hover:bg-primary/90 text-white text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-1"
                asChild
              >
                <Link href="/enhanced-dashboard">
                  <TrendingUp className="mr-2 h-5 w-5" />
                  Dashboard Avancé
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="px-8 py-3 bg-white hover:bg-gray-100 text-primary text-lg font-semibold rounded-lg border border-primary/20 hover:border-primary/40 shadow-sm hover:shadow transition-all duration-200"
                asChild
              >
                <Link href="/dashboard">
                  <BarChart3 className="mr-2 h-5 w-5" />
                  Dashboard Standard
                </Link>
              </Button>
            </div>
            <div className="mt-6">
              <Button
                variant="link"
                className="text-gray-600 hover:text-primary transition-colors"
                asChild
              >
                <a href="#waitlist">Rejoindre la liste d'attente</a>
              </Button>
            </div>
          </motion.div>
          
          <motion.div 
            className="w-full lg:w-1/2 relative"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="relative z-10 rounded-xl shadow-2xl overflow-hidden bg-white border border-gray-200">
              <svg 
                className="w-full h-auto" 
                viewBox="0 0 800 600" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Dashboard Background */}
                <rect width="800" height="600" fill="#f8fafc" />
                
                {/* Header Bar */}
                <rect x="60" y="80" width="680" height="60" rx="4" fill="#e2e8f0" />
                <rect x="80" y="100" width="200" height="20" rx="2" fill="#4f46e5" />
                <rect x="620" y="100" width="100" height="20" rx="2" fill="#3b82f6" />
                
                {/* Main Panel */}
                <rect x="60" y="160" width="680" height="380" rx="4" fill="#f1f5f9" />
                
                {/* Chart Title */}
                <rect x="80" y="180" width="300" height="30" rx="2" fill="#64748b" />
                
                {/* Line Chart */}
                <polyline 
                  points="80,350 140,310 200,330 260,290 320,270 380,280 440,260 500,240 560,250 620,220 680,200" 
                  stroke="#4f46e5" 
                  strokeWidth="3"
                  fill="none"
                />
                <circle cx="140" cy="310" r="4" fill="#4f46e5" />
                <circle cx="200" cy="330" r="4" fill="#4f46e5" />
                <circle cx="260" cy="290" r="4" fill="#4f46e5" />
                <circle cx="320" cy="270" r="4" fill="#4f46e5" />
                <circle cx="380" cy="280" r="4" fill="#4f46e5" />
                <circle cx="440" cy="260" r="4" fill="#4f46e5" />
                <circle cx="500" cy="240" r="4" fill="#4f46e5" />
                <circle cx="560" cy="250" r="4" fill="#4f46e5" />
                <circle cx="620" cy="220" r="4" fill="#4f46e5" />
                <circle cx="680" cy="200" r="4" fill="#4f46e5" />
                
                {/* X-Axis */}
                <rect x="80" y="380" width="640" height="1" rx="0.5" fill="#cbd5e1" />
                
                {/* KPI Cards */}
                <rect x="80" y="440" width="200" height="80" rx="4" fill="#3b82f6" fillOpacity="0.2" />
                <rect x="300" y="440" width="200" height="80" rx="4" fill="#4f46e5" fillOpacity="0.2" />
                <rect x="520" y="440" width="200" height="80" rx="4" fill="#8b5cf6" fillOpacity="0.2" />
                
                {/* KPI Labels */}
                <rect x="100" y="460" width="100" height="15" rx="2" fill="#3b82f6" />
                <rect x="100" y="485" width="60" height="20" rx="2" fill="#3b82f6" fillOpacity="0.6" />
                
                <rect x="320" y="460" width="100" height="15" rx="2" fill="#4f46e5" />
                <rect x="320" y="485" width="60" height="20" rx="2" fill="#4f46e5" fillOpacity="0.6" />
                
                <rect x="540" y="460" width="100" height="15" rx="2" fill="#8b5cf6" />
                <rect x="540" y="485" width="60" height="20" rx="2" fill="#8b5cf6" fillOpacity="0.6" />
              </svg>
            </div>
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-primary/10 rounded-full filter blur-3xl opacity-70 z-0"></div>
            <div className="absolute -top-10 -left-10 w-64 h-64 bg-blue-500/20 rounded-full filter blur-3xl opacity-70 z-0"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

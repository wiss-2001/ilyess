import React, { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

const faqs = [
  {
    question: "When will the platform be available?",
    answer: "We're planning to launch the beta version in Q1 2023. Early waitlist members will receive priority access to test the platform before the official launch."
  },
  {
    question: "Is there a free plan available?",
    answer: "Yes, we'll offer a free tier with basic features. Premium plans will be available for users who need advanced functionality and larger teams."
  },
  {
    question: "Can I integrate with other tools?",
    answer: "Absolutely! Our platform is designed to integrate seamlessly with popular tools like Slack, Microsoft Teams, Jira, Trello, and many more. We'll continue to add new integrations based on user feedback."
  },
  {
    question: "Is my data secure?",
    answer: "Security is our top priority. We use enterprise-grade encryption, regular security audits, and follow industry best practices to ensure your data remains safe and private at all times."
  },
  {
    question: "How many team members can I add?",
    answer: "Our plans scale with your team size. The free tier supports up to 3 team members, while premium plans support unlimited team members with role-based permissions."
  }
];

const FAQSection = () => {
  return (
    <section className="py-20 bg-white" id="faq">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 reveal">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600 reveal">Get answers to common questions about our platform.</p>
          </div>
          
          <div className="space-y-6">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem 
                  key={index} 
                  value={`item-${index + 1}`}
                  className="border border-gray-200 rounded-lg overflow-hidden reveal mb-4"
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <AccordionTrigger className="px-6 py-4 text-lg font-medium text-left text-gray-900 hover:no-underline hover:bg-gray-50">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="px-6 py-4 bg-gray-50 text-gray-600">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
          
          <div className="text-center mt-12 reveal">
            <p className="text-gray-600 mb-6">Still have questions? Feel free to contact us.</p>
            <Button
              variant="outline"
              className="bg-gray-100 hover:bg-gray-200 text-gray-900 font-medium py-2 px-6 border border-gray-300"
            >
              Contact Support
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;

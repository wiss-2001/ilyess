import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { waitlistEntryValidationSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

type FormValues = z.infer<typeof waitlistEntryValidationSchema>;

const WaitlistSection = () => {
  const { toast } = useToast();
  const [formSuccess, setFormSuccess] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(waitlistEntryValidationSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
    },
  });

  const waitlistMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/waitlist", data);
      return await response.json();
    },
    onSuccess: () => {
      form.reset();
      setFormSuccess(true);
      toast({
        title: "Success!",
        description: "You've been added to our waitlist.",
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to join waitlist. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    waitlistMutation.mutate(data);
  };

  return (
    <section className="py-20 bg-gradient-to-r from-primary to-primary/80 text-white" id="waitlist">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12 reveal">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Waitlist</h2>
          <p className="text-xl opacity-90">
            Be among the first to experience our platform when we launch. Early access members receive exclusive benefits and priority support.
          </p>
        </div>
        
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-xl overflow-hidden reveal">
          <div className="px-6 py-8">
            {formSuccess ? (
              <Alert className="bg-green-50 border-green-500 text-green-700">
                <CheckCircle className="h-4 w-4" />
                <AlertTitle>Thanks for joining our waitlist!</AlertTitle>
                <AlertDescription>
                  We'll notify you as soon as we launch.
                </AlertDescription>
              </Alert>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem className="space-y-1">
                        <FormLabel className="block text-sm font-medium text-gray-700">
                          Full Name
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="John Doe"
                            className="w-full text-gray-900 text-base"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-sm text-error-500" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem className="space-y-1">
                        <FormLabel className="block text-sm font-medium text-gray-700">
                          Email Address
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="john@example.com"
                            className="w-full text-gray-900 text-base"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-sm text-error-500" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem className="space-y-1">
                        <FormLabel className="block text-sm font-medium text-gray-700">
                          Company (Optional)
                        </FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Acme Inc."
                            className="w-full text-gray-900 text-base"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-sm text-error-500" />
                      </FormItem>
                    )}
                  />
                  
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 transition-colors"
                    disabled={waitlistMutation.isPending}
                  >
                    {waitlistMutation.isPending ? (
                      <span className="flex items-center justify-center">
                        <Loader2 className="animate-spin mr-2 h-4 w-4" />
                        Processing...
                      </span>
                    ) : (
                      "Join Waitlist"
                    )}
                  </Button>
                  
                  {waitlistMutation.isError && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Error</AlertTitle>
                      <AlertDescription>
                        {(waitlistMutation.error as any)?.message || "Failed to join waitlist. Please try again."}
                      </AlertDescription>
                    </Alert>
                  )}
                </form>
              </Form>
            )}
          </div>
        </div>
        
        <div className="max-w-xl mx-auto mt-10 text-center text-white text-opacity-80 text-sm reveal">
          <p>
            By joining our waitlist, you agree to our <a href="#" className="underline hover:text-white">Terms of Service</a> and <a href="#" className="underline hover:text-white">Privacy Policy</a>. We'll only use your email to send you updates about our product.
          </p>
        </div>
      </div>
    </section>
  );
};

export default WaitlistSection;

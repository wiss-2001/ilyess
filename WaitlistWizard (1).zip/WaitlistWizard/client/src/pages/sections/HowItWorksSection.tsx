import React from "react";

const steps = [
  {
    number: 1,
    title: "Sign Up",
    description: "Join our waitlist to be notified when we launch. Early access members receive special benefits."
  },
  {
    number: 2,
    title: "Create Profile",
    description: "Set up your personalized profile and configure your workspace to suit your needs."
  },
  {
    number: 3,
    title: "Start Innovating",
    description: "Begin using our powerful tools to bring your ideas to life and track your progress."
  }
];

const HowItWorksSection = () => {
  return (
    <section className="py-20 bg-white" id="howitworks">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 reveal">How It Works</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto reveal">
            Getting started with our platform is simple. Follow these steps to begin your innovation journey.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="relative flex flex-col items-center text-center reveal" 
              style={{ transitionDelay: `${index * 200}ms` }}
            >
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mb-6 z-10">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
              
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 left-1/2 w-full h-0.5 bg-primary/20 -z-10" style={{ transform: 'translateX(50%)' }}></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;

import React from "react";
import { 
  TrendingUp, 
  Users, 
  BarChart3, 
  FileUp, 
  PieChart, 
  Target,
  ArrowUpDown,
  Bell
} from "lucide-react";

const features = [
  {
    icon: <TrendingUp className="w-6 h-6 text-primary" />,
    title: "Prédiction Avancée",
    description: "Algorithmes d'apprentissage automatique pour prédire avec précision les futures transactions de change."
  },
  {
    icon: <Users className="w-6 h-6 text-primary" />,
    title: "Segmentation Client",
    description: "Classez automatiquement vos clients en segments basés sur leurs comportements et leur valeur."
  },
  {
    icon: <BarChart3 className="w-6 h-6 text-primary" />,
    title: "Analyse des Tendances",
    description: "Visualisez l'évolution des volumes par devise pour identifier les tendances commerciales clés."
  },
  {
    icon: <Target className="w-6 h-6 text-primary" />,
    title: "Opportunités Commerciales",
    description: "Identifiez automatiquement des opportunités d'affaires à fort potentiel avec nos algorithmes intelligents."
  },
  {
    icon: <FileUp className="w-6 h-6 text-primary" />,
    title: "Import Multi-Format",
    description: "Importez facilement vos données de transactions depuis des fichiers XLSB, XLSX ou CSV."
  },
  {
    icon: <PieChart className="w-6 h-6 text-primary" />,
    title: "KPIs Personnalisés",
    description: "Tableau de bord intuitif avec indicateurs de performance clés adaptés aux opérations de change."
  },
  {
    icon: <ArrowUpDown className="w-6 h-6 text-primary" />,
    title: "Analyse des Devises",
    description: "Évaluez les performances par paire de devises pour optimiser vos marges de change."
  },
  {
    icon: <Bell className="w-6 h-6 text-primary" />,
    title: "Alertes Proactives",
    description: "Soyez notifié automatiquement des opportunités et des transactions imminentes à fort potentiel."
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-20 bg-gray-50" id="features">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 reveal">
            Fonctionnalités <span className="bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">Avancées</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto reveal">
            Notre plateforme offre un ensemble complet d'outils d'analyse prédictive et de gestion proactive pour vos opérations de change.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 feature-card reveal" 
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;

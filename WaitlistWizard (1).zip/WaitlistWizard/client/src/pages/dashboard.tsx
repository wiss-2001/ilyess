import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { TransactionFileUploader } from "../components/TransactionFileUploader";
import { TransactionAnalysisList } from "../components/TransactionAnalysisList";
import { KPIDashboard } from "../components/KPIDashboard";
import { TransactionPrediction } from "@shared/schema";
import { getRecentTransactionAnalyses, getTransactionAnalysis } from "@/lib/api";

export default function Dashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("kpis");
  const [selectedAnalysis, setSelectedAnalysis] = useState<string | null>(null);

  // Fetch recent transaction analyses
  const { data: recentAnalysesData, isLoading: isLoadingAnalyses } = useQuery({
    queryKey: ["/api/transactions/analyses/recent"],
    queryFn: () => getRecentTransactionAnalyses(),
  });

  // Fetch selected analysis details when one is selected
  const { data: selectedAnalysisData, isLoading: isLoadingSelectedAnalysis } = useQuery({
    queryKey: ["/api/transactions/analyses", selectedAnalysis],
    queryFn: () => {
      if (!selectedAnalysis) return Promise.resolve(null);
      return getTransactionAnalysis(selectedAnalysis);
    },
    enabled: !!selectedAnalysis,
  });

  const handleFileUploadSuccess = (data: TransactionPrediction) => {
    toast({
      title: "Upload réussi",
      description: "Le fichier a été traité avec succès. Les prédictions sont prêtes.",
    });
    // Refresh the analyses list
    setSelectedAnalysis(data.filename);
  };

  const handleFileUploadError = (error: Error) => {
    toast({
      title: "Erreur d'upload",
      description: `Une erreur est survenue : ${error.message}`,
      variant: "destructive",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Tableau de Bord - Prédiction de Transactions</h1>
          <Link href="/">
            <Button variant="outline">Retour à l'accueil</Button>
          </Link>
        </div>
        <p className="text-muted-foreground mt-2">
          Analysez vos transactions bancaires et obtenez des prédictions précises
        </p>
      </header>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Nouvelles Données</CardTitle>
              <CardDescription>
                Téléchargez un fichier de transactions pour l'analyser
              </CardDescription>
            </CardHeader>
            <CardContent>
              <TransactionFileUploader 
                onSuccess={handleFileUploadSuccess}
                onError={handleFileUploadError}
              />
            </CardContent>
          </Card>

          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Analyses Récentes</CardTitle>
                <CardDescription>
                  Consultez vos analyses de transactions récentes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <TransactionAnalysisList
                  analyses={recentAnalysesData?.analyses || []}
                  isLoading={isLoadingAnalyses}
                  selectedAnalysis={selectedAnalysis}
                  onSelectAnalysis={(filename: string) => setSelectedAnalysis(filename)}
                />
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="md:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-2 mb-8">
              <TabsTrigger value="kpis">Indicateurs Clés</TabsTrigger>
              <TabsTrigger value="predictions">Prédictions</TabsTrigger>
            </TabsList>
            
            <TabsContent value="kpis" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Indicateurs Clés de Performance</CardTitle>
                  <CardDescription>
                    Vue d'ensemble des métriques importantes de vos transactions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <KPIDashboard 
                    analysisData={selectedAnalysisData?.analysis} 
                    isLoading={isLoadingSelectedAnalysis || !selectedAnalysis}
                  />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="predictions" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Prédictions de Transactions</CardTitle>
                  <CardDescription>
                    Prévisions de dates et montants des prochaines transactions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedAnalysis ? (
                    isLoadingSelectedAnalysis ? (
                      <div className="flex justify-center py-8">
                        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                      </div>
                    ) : (
                      <div>
                        {selectedAnalysisData?.analysis?.predictions ? (
                          <div className="space-y-4">
                            <h3 className="text-lg font-medium">
                              Prochaine transaction prévue:
                            </h3>
                            <div className="grid grid-cols-2 gap-4">
                              <Card>
                                <CardHeader className="py-2">
                                  <CardTitle className="text-sm">Date prévue</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <p className="text-2xl font-bold">
                                    {new Date(selectedAnalysisData.analysis.predictions.nextTransactionDate).toLocaleDateString('fr-FR')}
                                  </p>
                                </CardContent>
                              </Card>
                              <Card>
                                <CardHeader className="py-2">
                                  <CardTitle className="text-sm">Montant probable</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <p className="text-2xl font-bold">
                                    {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(selectedAnalysisData.analysis.predictions.predictedAmount || 0)}
                                  </p>
                                </CardContent>
                              </Card>
                            </div>
                            <div className="mt-4">
                              <p className="text-sm text-muted-foreground">
                                Basé sur l'analyse de {selectedAnalysisData?.analysis?.totalTransactions || 0} transactions
                              </p>
                            </div>
                          </div>
                        ) : (
                          <p>Aucune prédiction disponible pour cette analyse.</p>
                        )}
                      </div>
                    )
                  ) : (
                    <div className="py-8 text-center">
                      <p className="text-muted-foreground">
                        Sélectionnez une analyse dans la liste pour voir ses prédictions
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
import React, { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeroSection from "@/pages/sections/HeroSection";
import StatsSection from "@/pages/sections/StatsSection";
import FeaturesSection from "@/pages/sections/FeaturesSection";
import HowItWorksSection from "@/pages/sections/HowItWorksSection";
import TestimonialsSection from "@/pages/sections/TestimonialsSection";
import WaitlistSection from "@/pages/sections/WaitlistSection";
import FAQSection from "@/pages/sections/FAQSection";
import { useReveal } from "@/hooks/use-reveal";

const Home = () => {
  const { setupReveal } = useReveal();

  useEffect(() => {
    setupReveal();
  }, [setupReveal]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main>
        <HeroSection />
        <StatsSection />
        <FeaturesSection />
        <HowItWorksSection />
        <TestimonialsSection />
        <WaitlistSection />
        <FAQSection />
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;

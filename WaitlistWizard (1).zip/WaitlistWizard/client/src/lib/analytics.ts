// Simple analytics library for tracking page views and events

/**
 * Track a page view
 */
export const trackPageView = async () => {
  try {
    await fetch("/api/analytics/pageview", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url: window.location.pathname }),
    });
    console.log("Page view tracked");
  } catch (error) {
    console.error("Failed to track page view:", error);
  }
};

/**
 * Track a custom event
 */
export const trackEvent = async (eventName: string, eventData: Record<string, any> = {}) => {
  try {
    await fetch("/api/analytics/event", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: eventName,
        data: eventData,
        timestamp: new Date().toISOString(),
      }),
    });
    console.log(`Event tracked: ${eventName}`);
  } catch (error) {
    console.error(`Failed to track event ${eventName}:`, error);
  }
};

import { apiRequest } from "./queryClient";
import { TransactionPrediction } from "@shared/schema";

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  [key: string]: any;
}

// Type de réponse pour les analyses multiples
export interface AnalysesResponse extends ApiResponse<TransactionPrediction[]> {
  analyses: TransactionPrediction[];
  total: number;
}

// Type de réponse pour une analyse spécifique
export interface AnalysisResponse extends ApiResponse<TransactionPrediction> {
  analysis: TransactionPrediction;
}

// Type de réponse pour le téléchargement de fichier
export interface FileUploadResponse extends ApiResponse<TransactionPrediction> {
  analysis: TransactionPrediction;
}

/**
 * Récupère toutes les analyses de transactions
 */
export async function getAllTransactionAnalyses(): Promise<AnalysesResponse> {
  const response = await apiRequest("GET", "/api/transactions/analyses");
  return response.json();
}

/**
 * Récupère les analyses de transactions récentes
 * @param limit Nombre d'analyses à récupérer
 */
export async function getRecentTransactionAnalyses(limit?: number): Promise<AnalysesResponse> {
  const url = limit ? `/api/transactions/analyses/recent?limit=${limit}` : "/api/transactions/analyses/recent";
  const response = await apiRequest("GET", url);
  return response.json();
}

/**
 * Récupère une analyse de transaction spécifique par nom de fichier
 * @param filename Nom du fichier d'analyse
 */
export async function getTransactionAnalysis(filename: string): Promise<AnalysisResponse> {
  const response = await apiRequest("GET", `/api/transactions/analyses/${filename}`);
  return response.json();
}

/**
 * Télécharge un fichier de transactions pour analyse
 * @param file Fichier à télécharger
 */
export async function uploadTransactionFile(file: File): Promise<FileUploadResponse> {
  const formData = new FormData();
  formData.append("file", file);
  
  const response = await apiRequest("POST", "/api/transactions/upload", formData);
  return response.json();
}
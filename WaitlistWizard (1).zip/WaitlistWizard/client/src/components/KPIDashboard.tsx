import { Card, CardContent } from "@/components/ui/card";
import { 
  TransactionPrediction
} from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

interface KPIDashboardProps {
  analysisData?: TransactionPrediction;
  isLoading: boolean;
}

export function KPIDashboard({ analysisData, isLoading }: KPIDashboardProps) {
  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!analysisData) {
    return (
      <div className="py-8 text-center">
        <p className="text-muted-foreground">
          Sélectionnez une analyse dans la liste pour voir ses KPIs
        </p>
      </div>
    );
  }

  const { kpis } = analysisData;

  if (!kpis) {
    return (
      <div className="py-8 text-center">
        <p className="text-muted-foreground">
          Aucun KPI disponible pour cette analyse
        </p>
      </div>
    );
  }

  // Prepare data for charts
  const transactionsByMonth = kpis.transactionsByMonth || [];
  const transactionAmountByCategory = kpis.transactionAmountByCategory || [];
  const transactionFrequency = kpis.transactionFrequency || [];
  
  // Format amounts for display
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
  };

  // Define colors for pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-lg font-medium">Total Transactions</h3>
              <p className="text-3xl font-bold mt-2">{analysisData.totalTransactions}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-lg font-medium">Montant Moyen</h3>
              <p className="text-3xl font-bold mt-2">
                {formatAmount(kpis.averageTransactionAmount || 0)}
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-lg font-medium">Montant Total</h3>
              <p className="text-3xl font-bold mt-2">
                {formatAmount(kpis.totalTransactionAmount || 0)}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Transactions par mois */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Transactions par Mois</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={transactionsByMonth}
                  margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" angle={-45} textAnchor="end" height={50} />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} transactions`, 'Nombre']} />
                  <Bar dataKey="count" fill="#8884d8" name="Transactions" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Distribution par catégorie */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Distribution par Catégorie</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={transactionAmountByCategory}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="amount"
                    nameKey="category"
                    label={({ name, percent }: { name: string, percent: number }) => 
                      `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {transactionAmountByCategory.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={COLORS[index % COLORS.length]} 
                      />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [formatAmount(value as number), 'Montant']} 
                    labelFormatter={(category) => `Catégorie: ${category}`}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Fréquence des transactions */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Fréquence des Transactions</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={transactionFrequency}
                  margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" angle={-45} textAnchor="end" height={50} />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} jours`, 'Intervalle']} />
                  <Line type="monotone" dataKey="interval" stroke="#82ca9d" name="Jours entre transactions" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Statistiques des montants */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Statistiques des Montants</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-background p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Montant Minimum</p>
                  <p className="text-xl font-bold mt-1">{formatAmount(kpis.minTransactionAmount || 0)}</p>
                </div>
                <div className="bg-background p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Montant Maximum</p>
                  <p className="text-xl font-bold mt-1">{formatAmount(kpis.maxTransactionAmount || 0)}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-background p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Écart-Type</p>
                  <p className="text-xl font-bold mt-1">{formatAmount(kpis.stdDevTransactionAmount || 0)}</p>
                </div>
                <div className="bg-background p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Médiane</p>
                  <p className="text-xl font-bold mt-1">{formatAmount(kpis.medianTransactionAmount || 0)}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
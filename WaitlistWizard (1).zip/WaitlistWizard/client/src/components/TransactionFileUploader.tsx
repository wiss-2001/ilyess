import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { TransactionPrediction } from "@shared/schema";
import { uploadTransactionFile, FileUploadResponse } from "@/lib/api";

interface TransactionFileUploaderProps {
  onSuccess: (data: TransactionPrediction) => void;
  onError: (error: Error) => void;
}

export function TransactionFileUploader({ onSuccess, onError }: TransactionFileUploaderProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // File upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      return uploadTransactionFile(file);
    },
    onSuccess: (data: FileUploadResponse) => {
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      onSuccess(data.analysis);
    },
    onError: (error: Error) => {
      onError(error);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUpload = () => {
    if (!selectedFile) return;
    uploadMutation.mutate(selectedFile);
  };

  return (
    <div className="space-y-4">
      <div className="grid w-full items-center gap-1.5">
        <Label htmlFor="transaction-file">Fichier de Transactions</Label>
        <Input
          ref={fileInputRef}
          id="transaction-file"
          type="file"
          accept=".xlsx,.xlsb,.csv"
          onChange={handleFileChange}
          disabled={uploadMutation.isPending}
        />
        <p className="text-sm text-muted-foreground">
          Formats acceptés: XLSX, XLSB, CSV
        </p>
      </div>

      {selectedFile && (
        <Alert>
          <AlertDescription>
            Fichier sélectionné: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
          </AlertDescription>
        </Alert>
      )}

      <Button 
        onClick={handleUpload} 
        disabled={!selectedFile || uploadMutation.isPending}
        className="w-full"
      >
        {uploadMutation.isPending ? (
          <>
            <span className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"></span>
            Traitement en cours...
          </>
        ) : (
          "Télécharger et Analyser"
        )}
      </Button>
    </div>
  );
}
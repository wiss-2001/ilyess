import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp } from "lucide-react";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const isHomePage = location === "/";

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white bg-opacity-95 backdrop-blur-sm shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link href="/" className="flex items-center">
            <div className="flex items-center">
              <svg className="w-8 h-8 text-blue-600" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">BIAT PROACTIFX</span>
            </div>
          </Link>
          
          <nav className="hidden md:flex space-x-4">
            {isHomePage ? (
              <>
                <a href="#features" className="text-gray-600 hover:text-primary transition-colors font-medium">
                  Fonctionnalités
                </a>
                <a href="#howitworks" className="text-gray-600 hover:text-primary transition-colors font-medium">
                  Comment ça marche
                </a>
                <a href="#faq" className="text-gray-600 hover:text-primary transition-colors font-medium">
                  FAQ
                </a>
              </>
            ) : (
              <Link href="/" className="text-gray-600 hover:text-primary transition-colors font-medium">
                Accueil
              </Link>
            )}

            <Link href="/dashboard" className="text-gray-600 hover:text-primary transition-colors font-medium flex items-center">
              <BarChart3 className="h-4 w-4 mr-1" />
              Dashboard Standard
            </Link>
            
            <Link href="/enhanced-dashboard" className="text-gray-600 hover:text-primary transition-colors font-medium flex items-center">
              <TrendingUp className="h-4 w-4 mr-1" />
              Dashboard Avancé
            </Link>
          </nav>
          
          <div>
            {isHomePage ? (
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <a href="#waitlist">Rejoindre</a>
              </Button>
            ) : (
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <Link href="/">
                  Retour à l'accueil
                </Link>
              </Button>
            )}
          </div>
          
          <button 
            type="button" 
            className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:text-gray-900"
            aria-label="Menu"
            onClick={toggleMobileMenu}
          >
            <svg className="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>

        {/* Mobile menu, show/hide based on menu state */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <div className="flex flex-col space-y-3">
              {isHomePage ? (
                <>
                  <a 
                    href="#features" 
                    className="text-gray-600 hover:text-primary font-medium py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Fonctionnalités
                  </a>
                  <a 
                    href="#howitworks" 
                    className="text-gray-600 hover:text-primary font-medium py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Comment ça marche
                  </a>
                  <a 
                    href="#faq" 
                    className="text-gray-600 hover:text-primary font-medium py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    FAQ
                  </a>
                </>
              ) : (
                <Link
                  href="/"
                  className="text-gray-600 hover:text-primary font-medium py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Accueil
                </Link>
              )}

              <Link 
                href="/dashboard"
                className="text-gray-600 hover:text-primary font-medium py-2 flex items-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                <BarChart3 className="h-4 w-4 mr-1" />
                Dashboard Standard
              </Link>
              
              <Link 
                href="/enhanced-dashboard"
                className="text-gray-600 hover:text-primary font-medium py-2 flex items-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                <TrendingUp className="h-4 w-4 mr-1" />
                Dashboard Avancé
              </Link>

              <div className="pt-2">
                {isHomePage ? (
                  <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                    <a 
                      href="#waitlist"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Rejoindre la liste d'attente
                    </a>
                  </Button>
                ) : (
                  <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                    <Link 
                      href="/"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Retour à l'accueil
                    </Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;

import { useState, useEffect } from "react";
import { Link } from "wouter";
import { 
  BarChart3, 
  Bell, 
  Calendar, 
  Clock, 
  DollarSign, 
  Download, 
  ExternalLink, 
  FileUp, 
  Info, 
  PieChart, 
  Target, 
  TrendingUp, 
  Upload, 
  Users 
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart as RechartsPieChart, 
  Pie, 
  Cell 
} from "recharts";
import { uploadTransactionFile } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { TransactionPrediction } from "@shared/schema";

interface ClientSegment {
  clientId: string | number;
  segmentName: string;
  recencyDays: number;
  frequency: number;
  monetary: number;
  amountMean: number;
}

interface CommercialOpportunity {
  clientId: string | number;
  type: string;
  title: string;
  description: string;
  expectedAmount: number;
  preferredCurrencies: Record<string, number>;
  priority: string;
  probabilite: number;
}

interface CurrencyTrend {
  currency: string;
  latestVolume: number;
  transactionCount: number;
  averageAmount: number;
  growth: number;
  trending: boolean;
  monthlyData: {
    month: string;
    amount_sum: number;
    amount_count: number;
    volume_growth: number;
  }[];
}

interface EnhancedAnalysisData extends TransactionPrediction {
  clientSegments?: ClientSegment[];
  commercialOpportunities?: CommercialOpportunity[];
  currencyTrends?: CurrencyTrend[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function EnhancedDashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analysisData, setAnalysisData] = useState<EnhancedAnalysisData | null>(null);

  // Simulate upload progress
  useEffect(() => {
    if (isUploading && uploadProgress < 90) {
      const timer = setTimeout(() => {
        setUploadProgress(prev => prev + 10);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isUploading, uploadProgress]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(10);

    try {
      const response = await uploadTransactionFile(selectedFile);
      setUploadProgress(100);
      setAnalysisData(response.analysis as EnhancedAnalysisData);
      toast({
        title: "Analyse réussie",
        description: "Vos données ont été analysées avec succès.",
      });
    } catch (error) {
      toast({
        title: "Erreur d'analyse",
        description: error instanceof Error ? error.message : "Une erreur est survenue lors de l'analyse",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      setSelectedFile(null);
    }
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR');
  };

  // Calculate confidence color based on score
  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return "bg-green-500";
    if (score >= 0.6) return "bg-yellow-500";
    return "bg-red-500";
  };

  // Format large numbers with K, M suffix
  const formatLargeNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">
              BIAT PROACTIFX Prediction
            </h1>
            <p className="text-muted-foreground mt-2">
              Dashboard avancé pour l'analyse et la prédiction des opérations de change
            </p>
          </div>
          <Link href="/">
            <Button variant="outline">Retour à l'accueil</Button>
          </Link>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Analyse de Données</CardTitle>
              <CardDescription>
                Importez un fichier de transactions pour l'analyser
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="file-upload">Fichier de Transactions</Label>
                <Input
                  id="file-upload"
                  type="file"
                  onChange={handleFileChange}
                  accept=".xlsb,.xlsx,.csv"
                  disabled={isUploading}
                />
                <p className="text-xs text-muted-foreground">
                  Formats supportés: XLSB, XLSX, CSV
                </p>
              </div>

              {isUploading && (
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>Traitement en cours...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} />
                </div>
              )}

              {selectedFile && !isUploading && (
                <Alert variant="default">
                  <FileUp className="h-4 w-4" />
                  <AlertTitle>Fichier sélectionné</AlertTitle>
                  <AlertDescription className="text-xs">
                    {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                  </AlertDescription>
                </Alert>
              )}

              <Button 
                onClick={handleUpload} 
                disabled={!selectedFile || isUploading}
                className="w-full"
              >
                {isUploading ? (
                  <>
                    <span className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"></span>
                    Analyse en cours...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Analyser les Données
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {analysisData && (
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>Détails de l'Analyse</CardTitle>
                <CardDescription>
                  Informations sur les données analysées
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Fichier:</span>
                    <span className="text-sm">{analysisData.filename}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Nombre de transactions:</span>
                    <span className="text-sm">{analysisData.totalTransactions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Date d'analyse:</span>
                    <span className="text-sm">{new Date(analysisData.analysisDate).toLocaleString('fr-FR')}</span>
                  </div>
                  {analysisData.kpis?.uniqueClients && (
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Clients uniques:</span>
                      <span className="text-sm">{analysisData.kpis.uniqueClients}</span>
                    </div>
                  )}
                  {analysisData.lastTransactionDate && (
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Dernière transaction:</span>
                      <span className="text-sm">{formatDate(analysisData.lastTransactionDate)}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="lg:col-span-3">
          {!analysisData ? (
            <Card className="h-full flex items-center justify-center">
              <CardContent className="text-center py-20">
                <Info className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-xl font-medium mb-2">Aucune donnée analysée</p>
                <p className="text-muted-foreground">
                  Importez un fichier de transactions pour visualiser les analyses et prédictions
                </p>
              </CardContent>
            </Card>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-5 mb-8">
                <TabsTrigger value="overview">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Aperçu</span>
                </TabsTrigger>
                <TabsTrigger value="predictions">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Prévisions</span>
                </TabsTrigger>
                <TabsTrigger value="clients">
                  <Users className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Clients</span>
                </TabsTrigger>
                <TabsTrigger value="opportunities">
                  <Target className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Opportunités</span>
                </TabsTrigger>
                <TabsTrigger value="visualizations">
                  <PieChart className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Graphiques</span>
                </TabsTrigger>
              </TabsList>
              
              {/* Tab: Overview */}
              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-base font-medium">Montant Total</h3>
                        <p className="text-3xl font-bold mt-2">
                          {formatAmount(analysisData.kpis?.totalAmount || 0)}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-base font-medium">Transactions</h3>
                        <p className="text-3xl font-bold mt-2">
                          {analysisData.totalTransactions}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-base font-medium">Montant Moyen</h3>
                        <p className="text-3xl font-bold mt-2">
                          {formatAmount(analysisData.kpis?.averageTransactionAmount || 0)}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Currency Trends */}
                {analysisData.currencyTrends && analysisData.currencyTrends.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Tendances des Devises</CardTitle>
                      <CardDescription>Analyse des volumes par devise</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {analysisData.currencyTrends.slice(0, 4).map((trend, index) => (
                          <Card key={index} className="overflow-hidden border-0 shadow-md">
                            <CardContent className="p-4">
                              <div className="flex justify-between items-center mb-2">
                                <h4 className="font-semibold text-base">{trend.currency}</h4>
                                <Badge variant={trend.trending ? "default" : "destructive"}>
                                  {trend.growth > 0 ? '+' : ''}{trend.growth.toFixed(1)}%
                                </Badge>
                              </div>
                              <div className="mb-4">
                                <p className="text-sm text-muted-foreground">Volume total: {formatAmount(trend.latestVolume)}</p>
                                <p className="text-sm text-muted-foreground">Transactions: {trend.transactionCount}</p>
                              </div>
                              {trend.monthlyData && trend.monthlyData.length > 1 && (
                                <div className="h-32">
                                  <ResponsiveContainer width="100%" height="100%">
                                    <LineChart data={trend.monthlyData}>
                                      <CartesianGrid strokeDasharray="3 3" />
                                      <XAxis dataKey="month" fontSize={10} />
                                      <YAxis fontSize={10} />
                                      <RechartsTooltip />
                                      <Line type="monotone" dataKey="amount_sum" stroke="#8884d8" />
                                    </LineChart>
                                  </ResponsiveContainer>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* KPI Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Résumé des KPIs</CardTitle>
                    <CardDescription>Métriques clés de performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-background p-4 rounded-lg border">
                        <div className="flex items-center space-x-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Min. Amount</span>
                        </div>
                        <p className="text-lg font-bold mt-1">
                          {formatAmount(analysisData.kpis?.minTransactionAmount || 0)}
                        </p>
                      </div>
                      <div className="bg-background p-4 rounded-lg border">
                        <div className="flex items-center space-x-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Max. Amount</span>
                        </div>
                        <p className="text-lg font-bold mt-1">
                          {formatAmount(analysisData.kpis?.maxTransactionAmount || 0)}
                        </p>
                      </div>
                      <div className="bg-background p-4 rounded-lg border">
                        <div className="flex items-center space-x-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Avg. Interval</span>
                        </div>
                        <p className="text-lg font-bold mt-1">
                          {Math.round(analysisData.kpis?.avgDaysBetweenTransactions || 0)} jours
                        </p>
                      </div>
                      <div className="bg-background p-4 rounded-lg border">
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Période</span>
                        </div>
                        <p className="text-lg font-bold mt-1">
                          {analysisData.kpis?.dateRangeDays || 0} jours
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Tab: Predictions */}
              <TabsContent value="predictions" className="space-y-6">
                {analysisData.predictions ? (
                  <>
                    <Card className="overflow-hidden">
                      <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
                        <CardTitle className="text-white">Prochaine Transaction Prévue</CardTitle>
                        <CardDescription className="text-blue-100">
                          Basé sur l'analyse de {analysisData.totalTransactions} transactions historiques
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                          <div className="text-center">
                            <div className="text-sm font-medium text-muted-foreground mb-1">Date Prévue</div>
                            <div className="text-2xl font-bold">
                              {formatDate(analysisData.predictions.nextTransactionDate)}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              Dans {analysisData.predictions.daysUntilNextTransaction} jours
                            </div>
                          </div>
                          
                          <div className="text-center">
                            <div className="text-sm font-medium text-muted-foreground mb-1">Montant Prévu</div>
                            <div className="text-2xl font-bold">
                              {formatAmount(analysisData.predictions.predictedAmount || 0)}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              ±10% de variation possible
                            </div>
                          </div>
                          
                          <div className="text-center">
                            <div className="text-sm font-medium text-muted-foreground mb-1">Confiance</div>
                            <div className="flex justify-center items-center">
                              <div className="text-2xl font-bold mr-2">
                                {Math.round((analysisData.predictions.confidenceScore || 0) * 100)}%
                              </div>
                              <div className={`h-3 w-3 rounded-full ${getConfidenceColor(analysisData.predictions.confidenceScore || 0)}`}></div>
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              Score de fiabilité
                            </div>
                          </div>
                          
                          <div className="text-center">
                            <div className="text-sm font-medium text-muted-foreground mb-1">Actions</div>
                            <Button size="sm" className="w-full">
                              <Bell className="h-4 w-4 mr-2" />
                              Définir une Alerte
                            </Button>
                            <div className="text-sm text-muted-foreground mt-1">
                              Vous recevrez une notification
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Transaction Pattern */}
                      <Card>
                        <CardHeader>
                          <CardTitle>Modèle de Prédiction</CardTitle>
                          <CardDescription>
                            Facteurs influençant la prédiction
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm">Périodicité historique</span>
                                <span className="text-sm font-medium">40%</span>
                              </div>
                              <Progress value={40} className="h-2" />
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm">Saisonnalité</span>
                                <span className="text-sm font-medium">25%</span>
                              </div>
                              <Progress value={25} className="h-2" />
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm">Tendance montant</span>
                                <span className="text-sm font-medium">20%</span>
                              </div>
                              <Progress value={20} className="h-2" />
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm">Autres facteurs</span>
                                <span className="text-sm font-medium">15%</span>
                              </div>
                              <Progress value={15} className="h-2" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Visualization */}
                      <Card>
                        <CardHeader>
                          <CardTitle>Rythme des Transactions</CardTitle>
                          <CardDescription>
                            Intervalles entre les transactions
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          {analysisData.kpis?.transactionFrequency && (
                            <div className="h-64">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={analysisData.kpis.transactionFrequency.slice(-20)}>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis 
                                    dataKey="date" 
                                    angle={-45} 
                                    textAnchor="end" 
                                    height={60}
                                    tick={{fontSize: 10}}
                                  />
                                  <YAxis />
                                  <RechartsTooltip />
                                  <Line 
                                    type="monotone" 
                                    dataKey="interval" 
                                    stroke="#8884d8" 
                                    name="Jours" 
                                    strokeWidth={2}
                                    dot={{ r: 3 }}
                                    activeDot={{ r: 5 }}
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                  </>
                ) : (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <Info className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                      <p className="text-xl font-medium">Aucune prédiction disponible</p>
                      <p className="text-muted-foreground mt-2">
                        Nous n'avons pas pu générer de prédictions avec les données fournies.
                        Essayez d'importer un fichier contenant plus de transactions historiques.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              {/* Tab: Clients */}
              <TabsContent value="clients" className="space-y-6">
                {analysisData.clientSegments && analysisData.clientSegments.length > 0 ? (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <Card className="col-span-1 md:col-span-3">
                        <CardHeader>
                          <CardTitle>Segmentation des Clients</CardTitle>
                          <CardDescription>
                            Classification basée sur l'analyse RFM (Récence, Fréquence, Monétaire)
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="relative overflow-x-auto rounded-md border">
                            <table className="w-full text-sm text-left">
                              <thead className="text-xs uppercase bg-muted">
                                <tr>
                                  <th scope="col" className="px-6 py-3">ID Client</th>
                                  <th scope="col" className="px-6 py-3">Segment</th>
                                  <th scope="col" className="px-6 py-3">Récence (jours)</th>
                                  <th scope="col" className="px-6 py-3">Fréquence</th>
                                  <th scope="col" className="px-6 py-3">Valeur</th>
                                  <th scope="col" className="px-6 py-3">Montant Moyen</th>
                                </tr>
                              </thead>
                              <tbody>
                                {analysisData.clientSegments.slice(0, 8).map((client, index) => (
                                  <tr key={index} className="bg-card border-b">
                                    <td className="px-6 py-4 font-medium">{client.clientId}</td>
                                    <td className="px-6 py-4">
                                      <Badge variant={
                                        client.segmentName === 'Premium' ? 'default' :
                                        client.segmentName === 'High-Value' ? 'outline' : 'secondary'
                                      }>
                                        {client.segmentName}
                                      </Badge>
                                    </td>
                                    <td className="px-6 py-4">{client.recencyDays}</td>
                                    <td className="px-6 py-4">{client.frequency}</td>
                                    <td className="px-6 py-4">{formatAmount(client.monetary)}</td>
                                    <td className="px-6 py-4">{formatAmount(client.amountMean)}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          
                          {analysisData.clientSegments.length > 8 && (
                            <div className="text-center mt-4">
                              <Button variant="outline" size="sm">
                                Voir tous les clients ({analysisData.clientSegments.length})
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                      
                      <Card className="col-span-1">
                        <CardHeader>
                          <CardTitle>Distribution</CardTitle>
                          <CardDescription>
                            Répartition par segment
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          {/* Create segment distribution data */}
                          {(() => {
                            const segmentCounts: Record<string, number> = {};
                            analysisData.clientSegments.forEach(client => {
                              segmentCounts[client.segmentName] = (segmentCounts[client.segmentName] || 0) + 1;
                            });
                            
                            const data = Object.entries(segmentCounts).map(([name, value]) => ({
                              name,
                              value
                            }));
                            
                            return (
                              <div className="h-64">
                                <ResponsiveContainer width="100%" height="100%">
                                  <RechartsPieChart>
                                    <Pie
                                      data={data}
                                      cx="50%"
                                      cy="50%"
                                      innerRadius={40}
                                      outerRadius={80}
                                      fill="#8884d8"
                                      paddingAngle={5}
                                      dataKey="value"
                                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                      labelLine={false}
                                    >
                                      {data.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                      ))}
                                    </Pie>
                                    <RechartsTooltip />
                                  </RechartsPieChart>
                                </ResponsiveContainer>
                              </div>
                            );
                          })()}
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Actions Recommandées</CardTitle>
                        <CardDescription>
                          Stratégies par segment de clientèle
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-background p-4 rounded-lg border">
                            <h4 className="font-semibold mb-2 flex items-center">
                              <Badge variant="default" className="mr-2">Premium</Badge>
                              Clients de haute valeur
                            </h4>
                            <ul className="space-y-2 text-sm">
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-green-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">1</div>
                                <span>Proposer des taux d'échange préférentiels</span>
                              </li>
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-green-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">2</div>
                                <span>Service de conseiller dédié</span>
                              </li>
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-green-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">3</div>
                                <span>Alertes personnalisées sur volatilité</span>
                              </li>
                            </ul>
                          </div>
                          
                          <div className="bg-background p-4 rounded-lg border">
                            <h4 className="font-semibold mb-2 flex items-center">
                              <Badge variant="outline" className="mr-2">High-Value</Badge>
                              Clients à fort potentiel
                            </h4>
                            <ul className="space-y-2 text-sm">
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">1</div>
                                <span>Proposer des remises sur volumes</span>
                              </li>
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">2</div>
                                <span>Programme de fidélité avec récompenses</span>
                              </li>
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">3</div>
                                <span>Services additionnels de couverture de risque</span>
                              </li>
                            </ul>
                          </div>
                          
                          <div className="bg-background p-4 rounded-lg border">
                            <h4 className="font-semibold mb-2 flex items-center">
                              <Badge variant="secondary" className="mr-2">Mid/Low-Value</Badge>
                              Clients standard
                            </h4>
                            <ul className="space-y-2 text-sm">
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-gray-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">1</div>
                                <span>Proposer des services à valeur ajoutée</span>
                              </li>
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-gray-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">2</div>
                                <span>Automatisation des opérations</span>
                              </li>
                              <li className="flex items-start">
                                <div className="h-5 w-5 rounded-full bg-gray-500 text-white flex items-center justify-center text-xs mr-2 mt-0.5">3</div>
                                <span>Campagnes d'incitation à la transaction</span>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </>
                ) : (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <Users className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                      <p className="text-xl font-medium">Aucune donnée client disponible</p>
                      <p className="text-muted-foreground mt-2">
                        Nous n'avons pas pu identifier d'informations client dans les données fournies.
                        Assurez-vous que votre fichier contient une colonne d'identifiant client.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              {/* Tab: Opportunities */}
              <TabsContent value="opportunities" className="space-y-6">
                {analysisData.commercialOpportunities && analysisData.commercialOpportunities.length > 0 ? (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="col-span-1 md:col-span-3">
                        <CardHeader>
                          <CardTitle>Opportunités Commerciales</CardTitle>
                          <CardDescription>
                            Actions recommandées pour optimiser vos revenus
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {analysisData.commercialOpportunities.map((opportunity, index) => (
                              <Card key={index} className="border-l-4 border-l-blue-500">
                                <CardContent className="p-4">
                                  <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{opportunity.title}</h4>
                                    <Badge variant={
                                      opportunity.priority === 'high' ? 'destructive' :
                                      opportunity.priority === 'medium' ? 'default' : 'outline'
                                    }>
                                      {opportunity.priority}
                                    </Badge>
                                  </div>
                                  
                                  <p className="text-sm text-muted-foreground mb-3">
                                    {opportunity.description}
                                  </p>
                                  
                                  <div className="space-y-2 mb-3">
                                    <div className="flex justify-between text-sm">
                                      <span>Client ID:</span>
                                      <span className="font-medium">{opportunity.clientId}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                      <span>Montant prévu:</span>
                                      <span className="font-medium">{formatAmount(opportunity.expectedAmount)}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                      <span>Probabilité:</span>
                                      <span className="font-medium">{Math.round(opportunity.probabilite * 100)}%</span>
                                    </div>
                                  </div>
                                  
                                  <div className="flex justify-between mt-4">
                                    <Button variant="outline" size="sm">
                                      <Bell className="h-3 w-3 mr-1" />
                                      Rappel
                                    </Button>
                                    <Button size="sm">
                                      <ExternalLink className="h-3 w-3 mr-1" />
                                      Agir
                                    </Button>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Impact Commercial Potentiel</CardTitle>
                        <CardDescription>
                          Estimation de la valeur des opportunités
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <Card className="bg-background col-span-1 md:col-span-2">
                            <CardContent className="p-4">
                              <h4 className="text-sm font-medium mb-2">Valeur totale des opportunités</h4>
                              <div className="text-3xl font-bold mb-2">
                                {formatAmount(
                                  analysisData.commercialOpportunities.reduce(
                                    (sum, opp) => sum + (opp.expectedAmount * opp.probabilite), 
                                    0
                                  )
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground">
                                Basé sur {analysisData.commercialOpportunities.length} opportunités identifiées
                              </p>
                            </CardContent>
                          </Card>
                          
                          <Card className="bg-background">
                            <CardContent className="p-4">
                              <h4 className="text-sm font-medium mb-2">Revenu par client</h4>
                              <div className="text-3xl font-bold mb-2">
                                {formatAmount(analysisData.kpis?.totalAmount && analysisData.kpis?.uniqueClients ? 
                                  analysisData.kpis.totalAmount / analysisData.kpis.uniqueClients : 0
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground">
                                Moyenne historique
                              </p>
                            </CardContent>
                          </Card>
                          
                          <Card className="bg-background">
                            <CardContent className="p-4">
                              <h4 className="text-sm font-medium mb-2">Potentiel d'augmentation</h4>
                              <div className="text-3xl font-bold mb-2 text-green-500">
                                +{Math.round(
                                  analysisData.commercialOpportunities.reduce(
                                    (sum, opp) => sum + (opp.expectedAmount * opp.probabilite), 
                                    0
                                  ) / (analysisData.kpis?.totalAmount || 1) * 100
                                )}%
                              </div>
                              <p className="text-xs text-muted-foreground">
                                Par rapport au volume actuel
                              </p>
                            </CardContent>
                          </Card>
                        </div>
                      </CardContent>
                    </Card>
                  </>
                ) : (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <Target className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                      <p className="text-xl font-medium">Aucune opportunité identifiée</p>
                      <p className="text-muted-foreground mt-2">
                        Nous n'avons pas pu identifier d'opportunités commerciales avec les données fournies.
                        Essayez d'importer un fichier avec plus de données ou contenant des identifiants client.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              {/* Tab: Visualizations */}
              <TabsContent value="visualizations" className="space-y-6">
                <div className="grid grid-cols-1 gap-6">
                  {/* Amount Over Time */}
                  {analysisData.visualizations?.amountOverTime && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Montant des Transactions au Fil du Temps</CardTitle>
                        <CardDescription>
                          Évolution des montants de transaction par date
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="relative aspect-video w-full">
                          <img 
                            src={`data:image/png;base64,${analysisData.visualizations.amountOverTime}`} 
                            alt="Amount Over Time" 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Amount Distribution */}
                  {analysisData.visualizations?.amountDistribution && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Distribution des Montants</CardTitle>
                        <CardDescription>
                          Répartition des transactions par montant
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="relative aspect-video w-full">
                          <img 
                            src={`data:image/png;base64,${analysisData.visualizations.amountDistribution}`} 
                            alt="Amount Distribution" 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Category Distribution */}
                  {analysisData.visualizations?.categoryDistribution && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Distribution par Catégorie</CardTitle>
                        <CardDescription>
                          Nombre de transactions par catégorie
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="relative aspect-video w-full">
                          <img 
                            src={`data:image/png;base64,${analysisData.visualizations.categoryDistribution}`} 
                            alt="Category Distribution" 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Transaction Interval */}
                  {analysisData.visualizations?.transactionInterval && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Intervalle entre Transactions</CardTitle>
                        <CardDescription>
                          Distribution des jours entre transactions successives
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="relative aspect-video w-full">
                          <img 
                            src={`data:image/png;base64,${analysisData.visualizations.transactionInterval}`} 
                            alt="Transaction Interval" 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Monthly Trends */}
                  {analysisData.visualizations?.monthlyTrends && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Tendances Mensuelles</CardTitle>
                        <CardDescription>
                          Évolution mensuelle des montants et nombres de transactions
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="relative aspect-video w-full">
                          <img 
                            src={`data:image/png;base64,${analysisData.visualizations.monthlyTrends}`} 
                            alt="Monthly Trends" 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Fallback if no visualizations */}
                  {!analysisData.visualizations || Object.keys(analysisData.visualizations).length === 0 && (
                    <Card>
                      <CardContent className="py-10 text-center">
                        <PieChart className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                        <p className="text-xl font-medium">Aucune visualisation disponible</p>
                        <p className="text-muted-foreground mt-2">
                          Nous n'avons pas pu générer des visualisations avec les données fournies.
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </div>
  );
}
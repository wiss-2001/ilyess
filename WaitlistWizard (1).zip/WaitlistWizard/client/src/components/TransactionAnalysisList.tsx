import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { TransactionPrediction } from "@shared/schema";
import { Input } from "@/components/ui/input";

interface TransactionAnalysisListProps {
  analyses: TransactionPrediction[];
  isLoading: boolean;
  selectedAnalysis: string | null;
  onSelectAnalysis: (filename: string) => void;
}

export function TransactionAnalysisList({
  analyses,
  isLoading,
  selectedAnalysis,
  onSelectAnalysis,
}: TransactionAnalysisListProps) {
  const [searchTerm, setSearchTerm] = useState("");

  // Filter analyses by search term
  const filteredAnalyses = analyses.filter(
    (analysis) =>
      analysis.filename.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (analyses.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Aucune analyse disponible</p>
        <p className="text-sm mt-2">
          Téléchargez un fichier de transactions pour commencer
        </p>
      </div>
    );
  }

  // Formatter la date pour l'affichage
  const formatDate = (date: Date | string) => {
    const dateObj = date instanceof Date ? date : new Date(date);
    return dateObj.toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Input
          type="text"
          placeholder="Rechercher..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
        {filteredAnalyses.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">
            Aucun résultat trouvé
          </p>
        ) : (
          filteredAnalyses.map((analysis) => (
            <Card
              key={analysis.filename}
              className={`cursor-pointer transition-colors hover:bg-accent ${
                selectedAnalysis === analysis.filename ? "border-primary" : ""
              }`}
              onClick={() => onSelectAnalysis(analysis.filename)}
            >
              <CardContent className="p-3">
                <div className="flex flex-col">
                  <div className="flex justify-between items-center">
                    <div className="truncate max-w-[180px]" title={analysis.filename}>
                      {analysis.filename}
                    </div>
                    {selectedAnalysis === analysis.filename && (
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {formatDate(analysis.analysisDate)}
                  </div>
                  <div className="flex justify-between mt-2 text-xs">
                    <span>{analysis.totalTransactions} transactions</span>
                    <span>
                      {analysis.predictions
                        ? "Prédictions disponibles"
                        : "Aucune prédiction"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage as dataStorage } from "./storage";
import { waitlistEntryValidationSchema, transactionFileSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import multer from "multer";
import path from "path";
import fs from "fs";
import axios from "axios";
import { promisify } from "util";
import FormData from "form-data";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create uploads directory if it doesn't exist
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  // Configure multer for file uploads
  const multerStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, uploadsDir);
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    }
  });

  const upload = multer({ 
    storage: multerStorage,
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      if (ext === '.xlsx' || ext === '.xlsb' || ext === '.csv') {
        cb(null, true);
      } else {
        cb(new Error('Only Excel and CSV files are allowed'));
      }
    },
    limits: {
      fileSize: 10 * 1024 * 1024 // 10MB limit
    }
  });
  
  // API routes
  app.get("/api/health", (req: Request, res: Response) => {
    res.json({ status: "ok" });
  });

  // Analytics endpoint - simple page view counter
  let pageViews = 0;
  app.post("/api/analytics/pageview", (req: Request, res: Response) => {
    pageViews++;
    res.json({ success: true, pageViews });
  });
  
  // Transaction file upload endpoint
  app.post("/api/transactions/upload", upload.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "No file uploaded"
        });
      }
      
      const file = req.file;
      const fileExtension = path.extname(file.originalname).toLowerCase();
      let fileType: 'csv' | 'xlsx' | 'xlsb';
      
      if (fileExtension === '.csv') {
        fileType = 'csv';
      } else if (fileExtension === '.xlsx') {
        fileType = 'xlsx';
      } else if (fileExtension === '.xlsb') {
        fileType = 'xlsb';
      } else {
        // Cleanup the uploaded file
        fs.unlinkSync(file.path);
        return res.status(400).json({
          success: false,
          message: "Unsupported file format"
        });
      }
      
      // Store file metadata
      const fileData = {
        filename: file.filename,
        fileType: fileType,
        uploadDate: new Date()
      };
      
      // Forward the file to the Python API for processing
      const formData = new FormData();
      formData.append('file', fs.createReadStream(file.path));
      
      // Process the file with our Python API
      try {
        const response = await axios.post('http://localhost:5000/api/upload', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          },
          maxBodyLength: Infinity,
          maxContentLength: Infinity
        });
        
        // Store the analysis results
        if (response.status === 200) {
          const analysisData = response.data;
          await dataStorage.storeTransactionAnalysis(analysisData);
          
          return res.status(200).json({
            success: true,
            message: "File processed successfully",
            analysis: analysisData
          });
        } else {
          throw new Error(`Python API returned status ${response.status}`);
        }
      } catch (error: any) {
        console.error("Error processing file with Python API:", error.message);
        return res.status(500).json({
          success: false,
          message: "Error processing file",
          error: error.message
        });
      }
    } catch (error: any) {
      console.error("Error uploading transaction file:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while processing your file upload",
        error: error.message
      });
    }
  });
  
  // Get all transaction analyses
  app.get("/api/transactions/analyses", async (req: Request, res: Response) => {
    try {
      const analyses = await dataStorage.getAllTransactionAnalyses();
      return res.json({
        success: true,
        total: analyses.length,
        analyses
      });
    } catch (error) {
      console.error("Error fetching transaction analyses:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while fetching transaction analyses"
      });
    }
  });
  
  // Get recent transaction analyses
  app.get("/api/transactions/analyses/recent", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const analyses = await dataStorage.getRecentTransactionAnalyses(limit);
      return res.json({
        success: true,
        total: analyses.length,
        analyses
      });
    } catch (error) {
      console.error("Error fetching recent transaction analyses:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while fetching recent transaction analyses"
      });
    }
  });
  
  // Get a specific transaction analysis by filename
  app.get("/api/transactions/analyses/:filename", async (req: Request, res: Response) => {
    try {
      const filename = req.params.filename;
      const analysis = await dataStorage.getTransactionAnalysisByFilename(filename);
      
      if (!analysis) {
        return res.status(404).json({
          success: false,
          message: "Transaction analysis not found"
        });
      }
      
      return res.json({
        success: true,
        analysis
      });
    } catch (error) {
      console.error("Error fetching transaction analysis:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while fetching the transaction analysis"
      });
    }
  });

  // Waitlist submission endpoint
  app.post("/api/waitlist", async (req: Request, res: Response) => {
    try {
      // Validate the request body against the schema
      const validatedData = waitlistEntryValidationSchema.safeParse(req.body);
      
      if (!validatedData.success) {
        const validationError = fromZodError(validatedData.error);
        return res.status(400).json({
          success: false,
          message: "Validation failed",
          errors: validationError.details
        });
      }
      
      // Try to add the entry to the waitlist
      try {
        const entry = await dataStorage.createWaitlistEntry(validatedData.data);
        return res.status(201).json({
          success: true,
          message: "Successfully added to waitlist",
          entry: {
            id: entry.id,
            name: entry.name,
            email: entry.email,
            company: entry.company,
            createdAt: entry.createdAt
          }
        });
      } catch (error: any) {
        // Handle duplicate email error
        if (error.message === "Email already registered in waitlist") {
          return res.status(409).json({
            success: false,
            message: "This email is already registered in our waitlist"
          });
        }
        
        throw error; // Re-throw other errors to be caught by the outer catch block
      }
    } catch (error) {
      console.error("Error adding to waitlist:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while processing your request"
      });
    }
  });

  // Get all waitlist entries (protected, for admin purposes)
  app.get("/api/waitlist", async (req: Request, res: Response) => {
    try {
      const entries = await dataStorage.getAllWaitlistEntries();
      return res.json({
        success: true,
        total: entries.length,
        entries
      });
    } catch (error) {
      console.error("Error fetching waitlist entries:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while fetching waitlist entries"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { 
  waitlistEntries, 
  type WaitlistEntry, 
  type InsertWaitlistEntry,
  type TransactionFile, 
  type TransactionPrediction
} from "@shared/schema";

// Define user types since they're not in the schema yet
export type User = {
  id: number;
  username: string;
  email: string;
  name: string;
  createdAt: Date;
};

export type InsertUser = Omit<User, "id" | "createdAt">;

// Interface for storage operations
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Waitlist related methods
  createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry>;
  getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined>;
  getAllWaitlistEntries(): Promise<WaitlistEntry[]>;
  
  // Transaction analysis methods
  storeTransactionFile(file: TransactionFile): Promise<TransactionFile>;
  storeTransactionAnalysis(analysis: TransactionPrediction): Promise<TransactionPrediction>;
  getTransactionAnalysisByFilename(filename: string): Promise<TransactionPrediction | undefined>;
  getAllTransactionAnalyses(): Promise<TransactionPrediction[]>;
  getRecentTransactionAnalyses(limit?: number): Promise<TransactionPrediction[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private waitlist: Map<number, WaitlistEntry>;
  private transactionFiles: Map<string, TransactionFile>;
  private transactionAnalyses: Map<string, TransactionPrediction>;
  currentUserId: number;
  currentWaitlistId: number;

  constructor() {
    this.users = new Map();
    this.waitlist = new Map();
    this.transactionFiles = new Map();
    this.transactionAnalyses = new Map();
    this.currentUserId = 1;
    this.currentWaitlistId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Waitlist methods
  async createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry> {
    // Check if email already exists
    const existingEntry = await this.getWaitlistEntryByEmail(entry.email);
    if (existingEntry) {
      throw new Error("Email already registered in waitlist");
    }

    const id = this.currentWaitlistId++;
    const now = new Date();
    const waitlistEntry: WaitlistEntry = { 
      id, 
      name: entry.name,
      email: entry.email,
      company: entry.company || null,
      createdAt: now 
    };
    
    this.waitlist.set(id, waitlistEntry);
    return waitlistEntry;
  }

  async getWaitlistEntryByEmail(email: string): Promise<WaitlistEntry | undefined> {
    return Array.from(this.waitlist.values()).find(
      (entry) => entry.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async getAllWaitlistEntries(): Promise<WaitlistEntry[]> {
    return Array.from(this.waitlist.values());
  }
  
  // Transaction analysis methods
  async storeTransactionFile(file: TransactionFile): Promise<TransactionFile> {
    this.transactionFiles.set(file.filename, file);
    return file;
  }
  
  async storeTransactionAnalysis(analysis: TransactionPrediction): Promise<TransactionPrediction> {
    this.transactionAnalyses.set(analysis.filename, analysis);
    return analysis;
  }
  
  async getTransactionAnalysisByFilename(filename: string): Promise<TransactionPrediction | undefined> {
    return this.transactionAnalyses.get(filename);
  }
  
  async getAllTransactionAnalyses(): Promise<TransactionPrediction[]> {
    return Array.from(this.transactionAnalyses.values());
  }
  
  async getRecentTransactionAnalyses(limit: number = 5): Promise<TransactionPrediction[]> {
    const allAnalyses = Array.from(this.transactionAnalyses.values());
    // Sort by most recently uploaded (assuming they are stored in chronological order)
    return allAnalyses.slice(-limit);
  }
}

export const storage = new MemStorage();
